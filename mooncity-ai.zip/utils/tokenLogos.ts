// Token logo utility functions for fetching authentic token images

interface TokenLogoResponse {
  logoURI?: string
  image?: string
  thumb?: string
  small?: string
  large?: string
}

// Solana Token List API
const SOLANA_TOKEN_LIST_URL = "https://token.jup.ag/all"

// CoinGecko API for fallback
const COINGECKO_API_URL = "https://api.coingecko.com/api/v3"

// Cache for token logos to avoid repeated API calls
const logoCache = new Map<string, string>()

// Pre-defined logos for popular Solana tokens for instant display
const INSTANT_LOGOS: Record<string, string> = {
  BONK: "https://raw.githubusercontent.com/solana-labs/token-list/main/assets/mainnet/DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263/logo.png",
  SAMO: "https://raw.githubusercontent.com/solana-labs/token-list/main/assets/mainnet/7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU/logo.png",
  RAY: "https://raw.githubusercontent.com/solana-labs/token-list/main/assets/mainnet/4k3Dyjzvzp8eMZWUXbBCjEvwSkkk59S5iCNLY3QrkX6R/logo.png",
  ORCA: "https://raw.githubusercontent.com/solana-labs/token-list/main/assets/mainnet/orcaEKTdK7LKz57vaAYr9QeNsVEPfiu6QeMU1kektZE/logo.png",
  MNGO: "https://raw.githubusercontent.com/solana-labs/token-list/main/assets/mainnet/MangoCzJ36AjZyKwVj3VnYU4GTonjfVEnJmvvWaxLac/logo.png",
  COPE: "https://raw.githubusercontent.com/solana-labs/token-list/main/assets/mainnet/8HGyAAB1yoM1ttS7pXjHMa3dukTFGQggnFFH3hJZgzQh/logo.png",
  SRM: "https://raw.githubusercontent.com/solana-labs/token-list/main/assets/mainnet/SRMuApVNdxXokk5GT7XD5cUUgXMBCoAz2LHeuAoKWRt/logo.png",
  FIDA: "https://raw.githubusercontent.com/solana-labs/token-list/main/assets/mainnet/EchesyfXePKdLtoiZSL8pBe8Myagyy8ZRqsACNCFGnvp/logo.png",
  STEP: "https://raw.githubusercontent.com/solana-labs/token-list/main/assets/mainnet/StepAscQoEioFxxWGnh2sLBDFp9d8rvKz2Yp39iDpyT/logo.png",
  MEDIA:
    "https://raw.githubusercontent.com/solana-labs/token-list/main/assets/mainnet/ETAtLmCmsoiEEKfNrHKJ2kYy3MoABhU6NQvpSfij5tDs/logo.png",
  SOL: "https://raw.githubusercontent.com/solana-labs/token-list/main/assets/mainnet/So11111111111111111111111111111111111111112/logo.png",
  USDC: "https://raw.githubusercontent.com/solana-labs/token-list/main/assets/mainnet/EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v/logo.png",
}

/**
 * Generate a high-quality fallback logo URL with token styling
 */
function generateFallbackLogo(symbol: string, theme: string): string {
  const themeColors = {
    AI: { bg: "3742fa", color: "ffffff", emoji: "🤖" },
    Meme: { bg: "ff6b81", color: "ffffff", emoji: "🎭" },
    DeFi: { bg: "2ed573", color: "ffffff", emoji: "💰" },
    NFT: { bg: "9c88ff", color: "ffffff", emoji: "🎨" },
    Community: { bg: "ffa502", color: "ffffff", emoji: "👥" },
    Gaming: { bg: "ff4757", color: "ffffff", emoji: "🎮" },
    Infrastructure: { bg: "70a1ff", color: "ffffff", emoji: "🏗️" },
  }

  const config = themeColors[theme as keyof typeof themeColors] || themeColors.DeFi
  const firstLetter = symbol.charAt(0).toUpperCase()

  // Create a more detailed placeholder with better styling
  return `/placeholder.svg?height=40&width=40&text=${firstLetter}&bg=${config.bg}&color=${config.color}&fontSize=16&fontWeight=bold&borderRadius=50`
}

/**
 * Simplified token logo retrieval with better fallback handling
 */
export function getInstantTokenLogo(
  symbol: string,
  theme = "DeFi",
  mintAddress?: string,
): { url: string; isReady: boolean } {
  const cacheKey = `${symbol}-${mintAddress || "no-mint"}`

  // Check if we have a cached logo
  if (logoCache.has(cacheKey)) {
    return {
      url: logoCache.get(cacheKey)!,
      isReady: true,
    }
  }

  // Check instant logos for popular tokens
  if (INSTANT_LOGOS[symbol.toUpperCase()]) {
    const logo = INSTANT_LOGOS[symbol.toUpperCase()]
    logoCache.set(cacheKey, logo)
    return {
      url: logo,
      isReady: true,
    }
  }

  // Generate high-quality fallback immediately
  const fallbackLogo = generateFallbackLogo(symbol, theme)
  logoCache.set(cacheKey, fallbackLogo)

  // Fetch real logo in background and update cache
  fetchTokenLogoBackground(symbol, theme, mintAddress, cacheKey)

  return {
    url: fallbackLogo,
    isReady: true, // Fallback images are always ready
  }
}

/**
 * Fetch token logo in background and update cache
 */
async function fetchTokenLogoBackground(symbol: string, theme: string, mintAddress?: string, cacheKey?: string) {
  try {
    const key = cacheKey || `${symbol}-${mintAddress || "no-mint"}`

    // Try Solana Token List first
    let logoUrl = await fetchSolanaTokenLogo(symbol, mintAddress)

    // Fallback to CoinGecko
    if (!logoUrl) {
      logoUrl = await fetchCoinGeckoLogo(symbol)
    }

    // Update cache if we found a logo
    if (logoUrl && logoUrl !== logoCache.get(key)) {
      logoCache.set(key, logoUrl)

      // Trigger a re-render by dispatching a custom event
      if (typeof window !== "undefined") {
        window.dispatchEvent(
          new CustomEvent("tokenLogoUpdated", {
            detail: { symbol, logoUrl, cacheKey: key, isReady: true },
          }),
        )
      }
    }
  } catch (error) {
    console.warn("Background logo fetch failed:", error)
  }
}

/**
 * Fetch token logo from Solana Token List (Jupiter)
 */
async function fetchSolanaTokenLogo(symbol: string, mintAddress?: string): Promise<string | null> {
  try {
    const response = await fetch(SOLANA_TOKEN_LIST_URL)
    if (!response.ok) {
      throw new Error(`Failed to fetch from Solana Token List: ${response.status}`)
    }

    const tokens = await response.json()

    // First try to find by mint address if available
    if (mintAddress) {
      const token = tokens.find((t: any) => t.address === mintAddress)
      if (token?.logoURI) return token.logoURI
    }

    // Then try by symbol
    const token = tokens.find((t: any) => t.symbol.toLowerCase() === symbol.toLowerCase())
    return token?.logoURI || null
  } catch (error) {
    console.warn("Failed to fetch from Solana Token List:", error)
    return null
  }
}

/**
 * Fetch token logo from CoinGecko
 */
async function fetchCoinGeckoLogo(symbol: string): Promise<string | null> {
  try {
    const response = await fetch(`${COINGECKO_API_URL}/search?query=${encodeURIComponent(symbol)}`)
    if (!response.ok) {
      throw new Error(`Failed to fetch from CoinGecko: ${response.status}`)
    }

    const data = await response.json()
    const coin = data.coins?.find((c: any) => c.symbol.toLowerCase() === symbol.toLowerCase())

    if (coin) {
      // Get detailed coin info for logo
      const detailResponse = await fetch(`${COINGECKO_API_URL}/coins/${coin.id}`)
      if (!detailResponse.ok) {
        throw new Error(`Failed to fetch coin details: ${detailResponse.status}`)
      }

      const detailData = await detailResponse.json()
      return detailData.image?.small || detailData.image?.thumb || null
    }

    return null
  } catch (error) {
    console.warn("Failed to fetch from CoinGecko:", error)
    return null
  }
}

/**
 * Simplified preload function for token images
 */
export async function preloadTokenImages(): Promise<{ success: string[]; failed: string[] }> {
  const results = { success: [] as string[], failed: [] as string[] }

  try {
    const preloadPromises = Object.entries(INSTANT_LOGOS).map(async ([symbol, url]) => {
      try {
        const img = new Image()
        img.crossOrigin = "anonymous"

        await new Promise<void>((resolve, reject) => {
          img.onload = () => resolve()
          img.onerror = () => reject(new Error(`Failed to load ${symbol} logo`))
          img.src = url

          // Set a timeout to avoid hanging
          setTimeout(() => reject(new Error(`Timeout loading ${symbol} logo`)), 3000)
        })

        results.success.push(symbol)
      } catch (error) {
        results.failed.push(symbol)
        console.warn(`Failed to preload ${symbol} logo:`, error)
      }
    })

    await Promise.allSettled(preloadPromises)
    return results
  } catch (error) {
    console.error("Error in preloadTokenImages:", error)
    return results
  }
}

/**
 * Get popular Solana token logos for realistic mock data
 */
export const POPULAR_SOLANA_TOKENS = [
  { symbol: "SOL", name: "Solana", theme: "Infrastructure", realLogo: true },
  { symbol: "USDC", name: "USD Coin", theme: "DeFi", realLogo: true },
  { symbol: "RAY", name: "Raydium", theme: "DeFi", realLogo: true },
  { symbol: "SRM", name: "Serum", theme: "DeFi", realLogo: true },
  { symbol: "COPE", name: "Cope", theme: "Meme", realLogo: true },
  { symbol: "FIDA", name: "Bonfida", theme: "DeFi", realLogo: true },
  { symbol: "MNGO", name: "Mango", theme: "DeFi", realLogo: true },
  { symbol: "ORCA", name: "Orca", theme: "DeFi", realLogo: true },
  { symbol: "SAMO", name: "Samoyedcoin", theme: "Meme", realLogo: true },
  { symbol: "BONK", name: "Bonk", theme: "Meme", realLogo: true },
]

/**
 * Legacy function for backward compatibility
 */
export async function getTokenLogo(symbol: string, theme = "DeFi", mintAddress?: string): Promise<string> {
  const result = getInstantTokenLogo(symbol, theme, mintAddress)
  return result.url
}

/**
 * Legacy function for backward compatibility
 */
export async function batchGetTokenLogos(
  tokens: Array<{ symbol: string; theme: string; mintAddress?: string }>,
): Promise<Map<string, string>> {
  const logoMap = new Map<string, string>()

  for (const token of tokens) {
    const logo = await getTokenLogo(token.symbol, token.theme, token.mintAddress)
    logoMap.set(token.symbol, logo)
  }

  return logoMap
}
