"use client"

import { useEffect, useState, useRef } from "react"

interface RollingNumberProps {
  value: number
  className?: string
  duration?: number
}

export default function RollingNumber({ value, className = "", duration = 500 }: RollingNumberProps) {
  const [displayValue, setDisplayValue] = useState(value)
  const [isAnimating, setIsAnimating] = useState(false)
  const previousValue = useRef(value)

  useEffect(() => {
    if (value !== previousValue.current) {
      setIsAnimating(true)

      // Start the rolling animation
      setTimeout(() => {
        setDisplayValue(value)
        previousValue.current = value

        // End animation after duration
        setTimeout(() => {
          setIsAnimating(false)
        }, duration)
      }, 50)
    }
  }, [value, duration])

  const formatNumber = (num: number) => {
    return num.toLocaleString()
  }

  return (
    <div className={`relative overflow-hidden ${className}`}>
      <div
        className={`transition-transform duration-${duration} ease-in-out ${
          isAnimating ? "animate-bounce-subtle" : ""
        }`}
      >
        {formatNumber(displayValue)}
      </div>

      {/* Rolling effect overlay */}
      {isAnimating && (
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-blue-400/20 to-transparent animate-slide-up" />
      )}
    </div>
  )
}
