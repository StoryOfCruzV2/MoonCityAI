"use client"

import { useEffect, useState, useRef } from "react"

interface RollingCounterProps {
  value: number
  className?: string
  duration?: number
  prefix?: string
  suffix?: string
  decimals?: number
  formatter?: (value: number) => string
}

export default function RollingCounter({
  value,
  className = "",
  duration = 500,
  prefix = "",
  suffix = "",
  decimals = 0,
  formatter,
}: RollingCounterProps) {
  const [displayValue, setDisplayValue] = useState(value)
  const [isAnimating, setIsAnimating] = useState(false)
  const previousValue = useRef(value)
  const animationFrameRef = useRef<number | null>(null)
  const startTimeRef = useRef<number | null>(null)
  const startValueRef = useRef<number>(value)

  // Format the number with proper separators and decimals
  const formatNumber = (num: number): string => {
    if (formatter) return formatter(num)

    return (
      prefix +
      num.toLocaleString(undefined, {
        minimumFractionDigits: decimals,
        maximumFractionDigits: decimals,
      }) +
      suffix
    )
  }

  useEffect(() => {
    // Only animate if the value has changed
    if (value !== previousValue.current) {
      // Always ensure we're incrementing (for volume tracking)
      if (value < previousValue.current) {
        return
      }

      setIsAnimating(true)
      startValueRef.current = previousValue.current
      previousValue.current = value
      startTimeRef.current = null

      // Cancel any existing animation
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current)
      }

      // Start the animation
      const animate = (timestamp: number) => {
        if (!startTimeRef.current) startTimeRef.current = timestamp
        const elapsed = timestamp - startTimeRef.current
        const progress = Math.min(elapsed / duration, 1)

        // Easing function for smooth animation
        const easeOutQuart = 1 - Math.pow(1 - progress, 4)

        // Calculate the current value based on progress
        const currentValue = startValueRef.current + (value - startValueRef.current) * easeOutQuart

        setDisplayValue(currentValue)

        if (progress < 1) {
          animationFrameRef.current = requestAnimationFrame(animate)
        } else {
          setDisplayValue(value)
          setIsAnimating(false)
          animationFrameRef.current = null
        }
      }

      animationFrameRef.current = requestAnimationFrame(animate)
    }

    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current)
      }
    }
  }, [value, duration])

  return (
    <div className={`relative overflow-hidden ${className}`}>
      <div className="transition-all duration-300">{formatNumber(displayValue)}</div>

      {/* Rolling effect overlay */}
      {isAnimating && (
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-green-400/20 to-transparent animate-slide-up" />
      )}
    </div>
  )
}
