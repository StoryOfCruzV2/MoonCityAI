"use client"

import { useState, useEffect, useCallback, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import Image from "next/image"
import { getInstantTokenLogo, preloadTokenImages } from "@/utils/tokenLogos"
import { AlertCircle, Eye, AlertTriangle } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

interface TokenLaunch {
  id: string
  symbol: string
  name: string
  mintTime: string
  volume: number
  aiScore: number
  theme: string
  isNew?: boolean
  imageUrl: string
  pumpfunId: string
  mintAddress?: string
}

// Simplified token image component with better error handling
const TokenImage = ({
  symbol,
  imageUrl,
  theme,
  isNew,
}: {
  symbol: string
  imageUrl: string
  theme: string
  isNew?: boolean
}) => {
  const [src, setSrc] = useState(imageUrl)
  const [isLoaded, setIsLoaded] = useState(false)
  const [error, setError] = useState(false)

  // Reset state when image URL changes
  useEffect(() => {
    setSrc(imageUrl)
    setIsLoaded(false)
    setError(false)
  }, [imageUrl])

  // Generate fallback image URL with better styling
  const getFallbackImage = () => {
    const themeColors: Record<string, { bg: string; emoji: string }> = {
      AI: { bg: "3742fa", emoji: "🤖" },
      Meme: { bg: "ff6b81", emoji: "🎭" },
      DeFi: { bg: "2ed573", emoji: "💰" },
      NFT: { bg: "9c88ff", emoji: "🎨" },
      Community: { bg: "ffa502", emoji: "👥" },
      Gaming: { bg: "ff4757", emoji: "🎮" },
      Infrastructure: { bg: "70a1ff", emoji: "🏗️" },
    }

    const config = themeColors[theme] || themeColors.DeFi
    const firstLetter = symbol.charAt(0).toUpperCase()

    return `/placeholder.svg?height=40&width=40&text=${firstLetter}&bg=${config.bg}&color=ffffff`
  }

  const handleError = () => {
    if (!error) {
      setError(true)
      setSrc(getFallbackImage())
      // Force load state to true for fallback images
      setIsLoaded(true)
    }
  }

  const handleLoad = () => {
    setIsLoaded(true)
  }

  return (
    <div className="relative w-10 h-10 overflow-hidden rounded-full bg-gradient-to-br from-purple-400/30 to-purple-600/30 border border-purple-300/50 flex items-center justify-center">
      {/* Loading spinner - only show if not loaded and not error */}
      {!isLoaded && !error && (
        <div className="absolute inset-0 flex items-center justify-center z-10">
          <div className="w-4 h-4 border-2 border-purple-400 border-t-transparent rounded-full animate-spin"></div>
        </div>
      )}

      {/* Main image */}
      <Image
        src={src || getFallbackImage()}
        alt={symbol}
        width={40}
        height={40}
        className={`object-cover rounded-full transition-all duration-300 ${
          isLoaded ? "opacity-100 scale-100" : "opacity-0 scale-95"
        }`}
        priority={isNew}
        onLoad={handleLoad}
        onError={handleError}
        unoptimized={src.includes("/placeholder.svg")} // Don't optimize placeholder SVGs
      />

      {/* New token indicator */}
      {isNew && isLoaded && (
        <div className="absolute -top-1 -right-1 w-3 h-3 bg-green-400 rounded-full animate-ping"></div>
      )}
    </div>
  )
}

// Mock data with simplified structure and guaranteed images
const createMockTokens = (): TokenLaunch[] => {
  const tokens = [
    {
      id: "1",
      symbol: "BONK",
      name: "Bonk",
      mintTime: "2m ago",
      volume: 8400,
      aiScore: 94,
      theme: "Meme",
      pumpfunId: "pf-0x8a23",
      mintAddress: "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263",
    },
    {
      id: "2",
      symbol: "SAMO",
      name: "Samoyedcoin",
      mintTime: "5m ago",
      volume: 7200,
      aiScore: 91,
      theme: "Meme",
      pumpfunId: "pf-0x4b12",
      mintAddress: "7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU",
    },
    {
      id: "3",
      symbol: "RAY",
      name: "Raydium",
      mintTime: "8m ago",
      volume: 6800,
      aiScore: 88,
      theme: "DeFi",
      pumpfunId: "pf-0x7f31",
      mintAddress: "4k3Dyjzvzp8eMZWUXbBCjEvwSkkk59S5iCNLY3QrkX6R",
    },
    {
      id: "4",
      symbol: "ORCA",
      name: "Orca",
      mintTime: "12m ago",
      volume: 9100,
      aiScore: 85,
      theme: "DeFi",
      pumpfunId: "pf-0x2e45",
      mintAddress: "orcaEKTdK7LKz57vaAYr9QeNsVEPfiu6QeMU1kektZE",
    },
    {
      id: "5",
      symbol: "MNGO",
      name: "Mango",
      mintTime: "15m ago",
      volume: 8900,
      aiScore: 96,
      theme: "DeFi",
      pumpfunId: "pf-0x9a67",
      mintAddress: "MangoCzJ36AjZyKwVj3VnYU4GTonjfVEnJmvvWaxLac",
    },
    {
      id: "6",
      symbol: "COPE",
      name: "Cope",
      mintTime: "18m ago",
      volume: 7600,
      aiScore: 89,
      theme: "Meme",
      pumpfunId: "pf-0x3d19",
      mintAddress: "8HGyAAB1yoM1ttS7pXjHMa3dukTFGQggnFFH3hJZgzQh",
    },
    {
      id: "7",
      symbol: "SRM",
      name: "Serum",
      mintTime: "22m ago",
      volume: 6200,
      aiScore: 82,
      theme: "DeFi",
      pumpfunId: "pf-0x6c28",
      mintAddress: "SRMuApVNdxXokk5GT7XD5cUUgXMBCoAz2LHeuAoKWRt",
    },
    {
      id: "8",
      symbol: "FIDA",
      name: "Bonfida",
      mintTime: "25m ago",
      volume: 5800,
      aiScore: 79,
      theme: "DeFi",
      pumpfunId: "pf-0x5f14",
      mintAddress: "EchesyfXePKdLtoiZSL8pBe8Myagyy8ZRqsACNCFGnvp",
    },
  ]

  return tokens.map((token) => {
    const logoResult = getInstantTokenLogo(token.symbol, token.theme, token.mintAddress)
    return {
      ...token,
      imageUrl: logoResult.url,
    }
  })
}

const tickerTokens = [
  "BONK +24.5%",
  "SAMO +18.7%",
  "RAY +12.3%",
  "ORCA +15.8%",
  "MNGO +31.2%",
  "COPE +19.4%",
  "SRM +8.9%",
  "FIDA -2.1%",
  "STEP +22.6%",
  "MEDIA +11.7%",
]

// Expanded list of crypto meta names
const cryptoMetaNames = [
  // Real Solana tokens
  {
    symbol: "SOL",
    name: "Solana",
    theme: "Infrastructure",
    mintAddress: "So11111111111111111111111111111111111111112",
  },
  { symbol: "USDC", name: "USD Coin", theme: "DeFi", mintAddress: "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v" },
  { symbol: "RAY", name: "Raydium", theme: "DeFi", mintAddress: "4k3Dyjzvzp8eMZWUXbBCjEvwSkkk59S5iCNLY3QrkX6R" },
  { symbol: "SRM", name: "Serum", theme: "DeFi", mintAddress: "SRMuApVNdxXokk5GT7XD5cUUgXMBCoAz2LHeuAoKWRt" },
  { symbol: "COPE", name: "Cope", theme: "Meme", mintAddress: "8HGyAAB1yoM1ttS7pXjHMa3dukTFGQggnFFH3hJZgzQh" },
  { symbol: "FIDA", name: "Bonfida", theme: "DeFi", mintAddress: "EchesyfXePKdLtoiZSL8pBe8Myagyy8ZRqsACNCFGnvp" },
  { symbol: "MNGO", name: "Mango", theme: "DeFi", mintAddress: "MangoCzJ36AjZyKwVj3VnYU4GTonjfVEnJmvvWaxLac" },
  { symbol: "ORCA", name: "Orca", theme: "DeFi", mintAddress: "orcaEKTdK7LKz57vaAYr9QeNsVEPfiu6QeMU1kektZE" },
  { symbol: "SAMO", name: "Samoyedcoin", theme: "Meme", mintAddress: "7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU" },
  { symbol: "BONK", name: "Bonk", theme: "Meme", mintAddress: "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263" },

  // AI themed tokens
  { symbol: "AIDOG", name: "AI Doge Protocol", theme: "AI" },
  { symbol: "PEPEAI", name: "Pepe Intelligence", theme: "AI" },
  { symbol: "AIFRENS", name: "AI Friends Network", theme: "AI" },
  { symbol: "REKTAI", name: "Rekt AI Recovery", theme: "AI" },
  { symbol: "BASEDAI", name: "Based AI Network", theme: "AI" },

  // Meme tokens
  { symbol: "GIGACHD", name: "Giga Chad Token", theme: "Meme" },
  { symbol: "PEPELRD", name: "Pepe Lord", theme: "Meme" },
  { symbol: "WOJAK", name: "Wojak Finance", theme: "Meme" },
  { symbol: "DEGEN", name: "Degen Token", theme: "Meme" },
  { symbol: "CHAD", name: "Chad Finance", theme: "Meme" },

  // NFT and Gaming tokens
  { symbol: "SOLAPE", name: "Solana Ape Club", theme: "NFT" },
  { symbol: "PIXEL", name: "Pixel Art NFT", theme: "NFT" },
  { symbol: "GAME", name: "Game Protocol", theme: "Gaming" },
  { symbol: "PLAY", name: "Play to Earn", theme: "Gaming" },
  { symbol: "QUEST", name: "Quest Token", theme: "Gaming" },

  // DeFi and Infrastructure tokens
  { symbol: "DIAMND", name: "Diamond Hands DAO", theme: "Community" },
  { symbol: "HODLR", name: "Hodler Protocol", theme: "DeFi" },
  { symbol: "YIELD", name: "Yield Protocol", theme: "DeFi" },
  { symbol: "BRIDGE", name: "Bridge Protocol", theme: "Infrastructure" },
  { symbol: "NODE", name: "Node Network", theme: "Infrastructure" },
]

export default function LiveLaunches() {
  const [tokens, setTokens] = useState<TokenLaunch[]>([])
  const [timeFilter, setTimeFilter] = useState("all")
  const [volumeFilter, setVolumeFilter] = useState("all")
  const [themeFilter, setThemeFilter] = useState("all")
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  // Track which tokens have already been shown to prevent repeats
  const usedTokensRef = useRef<Set<string>>(new Set())

  // Initialize tokens and preload images
  useEffect(() => {
    const initializeTokens = async () => {
      try {
        setLoading(true)

        // Start preloading in background
        preloadTokenImages().catch((err) => {
          console.warn("Token image preloading had some failures:", err)
          // Non-critical error, continue with initialization
        })

        // Initialize tokens with mock data
        const initialTokens = createMockTokens()
        setTokens(initialTokens)

        // Track initial tokens as used
        usedTokensRef.current = new Set(initialTokens.map((token) => token.symbol))

        setLoading(false)
      } catch (err) {
        console.error("Failed to initialize tokens:", err)
        setError("Failed to load token data. Please refresh the page.")
        setLoading(false)
      }
    }

    initializeTokens()
  }, [])

  // Get available tokens that haven't been used yet
  const getAvailableTokens = useCallback(
    (count = 1) => {
      const availableTokens = cryptoMetaNames.filter((token) => !usedTokensRef.current.has(token.symbol))

      // If we don't have enough available tokens, reset the tracking (but keep current displayed tokens)
      if (availableTokens.length < count) {
        const currentTokenSymbols = new Set(tokens.map((token) => token.symbol))
        usedTokensRef.current = currentTokenSymbols
        const refreshedAvailable = cryptoMetaNames.filter((token) => !currentTokenSymbols.has(token.symbol))

        // Shuffle and return the requested count
        return [...refreshedAvailable].sort(() => Math.random() - 0.5).slice(0, count)
      }

      // Shuffle and return the requested count
      return [...availableTokens].sort(() => Math.random() - 0.5).slice(0, count)
    },
    [tokens],
  )

  // Simulate new token arrivals with guaranteed images
  useEffect(() => {
    // Only start the interval after tokens are initialized
    if (loading || error) return

    const interval = setInterval(() => {
      try {
        // Get a random token that hasn't been used yet
        const selectedToken = getAvailableTokens(1)[0]
        if (!selectedToken) return

        // Mark this token as used
        usedTokensRef.current.add(selectedToken.symbol)

        // Create new token object with guaranteed image
        const logoResult = getInstantTokenLogo(selectedToken.symbol, selectedToken.theme, selectedToken.mintAddress)

        const newToken: TokenLaunch = {
          id: `${Date.now()}`,
          symbol: selectedToken.symbol,
          name: selectedToken.name,
          mintTime: "Just now",
          volume: Math.floor(Math.random() * (9200 - 5600 + 1)) + 5600,
          aiScore: Math.floor(Math.random() * 30) + 70,
          theme: selectedToken.theme,
          isNew: true,
          imageUrl: logoResult.url, // This will always have a value (real logo or fallback)
          pumpfunId: `pf-0x${Math.floor(Math.random() * 10000)
            .toString(16)
            .padStart(4, "0")}`,
          mintAddress: selectedToken.mintAddress,
        }

        // Add the new token and keep only the most recent tokens
        setTokens((prev) => [newToken, ...prev.slice(0, 15)])

        // Remove new flag after animation
        setTimeout(() => {
          setTokens((prev) => prev.map((token) => (token.id === newToken.id ? { ...token, isNew: false } : token)))
        }, 3000)
      } catch (err) {
        console.warn("Error generating new token:", err)
        // Non-critical error, continue with next interval
      }
    }, 2000)

    return () => clearInterval(interval)
  }, [loading, error, getAvailableTokens])

  // Apply filters
  const filteredTokens = tokens.filter((token) => {
    if (themeFilter !== "all" && token.theme !== themeFilter) return false
    if (volumeFilter === "high" && token.volume < 8000) return false
    if (volumeFilter === "low" && token.volume >= 8000) return false
    return true
  })

  // Helper functions
  const formatVolume = (volume: number) => {
    if (volume >= 1000000) return `$${(volume / 1000000).toFixed(1)}M`
    if (volume >= 1000) return `$${(volume / 1000).toFixed(1)}K`
    return `$${volume}`
  }

  const getScoreColor = (score: number) => {
    if (score >= 90) return "text-green-400"
    if (score >= 80) return "text-yellow-400"
    if (score >= 70) return "text-orange-400"
    return "text-red-400"
  }

  const getThemeColor = (theme: string) => {
    switch (theme) {
      case "AI":
        return "bg-blue-500/20 border-blue-400/40 text-blue-200"
      case "Meme":
        return "bg-pink-500/20 border-pink-400/40 text-pink-200"
      case "DeFi":
        return "bg-green-500/20 border-green-400/40 text-green-200"
      case "NFT":
        return "bg-purple-500/20 border-purple-400/40 text-purple-200"
      case "Community":
        return "bg-orange-500/20 border-orange-400/40 text-orange-200"
      case "Infrastructure":
        return "bg-cyan-500/20 border-cyan-400/40 text-cyan-200"
      case "Gaming":
        return "bg-red-500/20 border-red-400/40 text-red-200"
      default:
        return "bg-purple-500/20 border-purple-400/40 text-purple-200"
    }
  }

  // Show loading state
  if (loading) {
    return (
      <section className="py-8 px-4">
        <div className="container mx-auto">
          <div className="flex items-center justify-center mb-6">
            <div className="bg-gradient-to-r from-purple-500/20 to-purple-600/20 backdrop-blur-md border border-purple-300/30 rounded-full px-6 py-3 flex items-center gap-3">
              <div className="w-4 h-4 border-2 border-purple-400 border-t-transparent rounded-full animate-spin"></div>
              <span className="text-purple-200 font-orbitron text-sm">Loading live token data...</span>
            </div>
          </div>
        </div>
      </section>
    )
  }

  // Show error state
  if (error) {
    return (
      <section className="py-8 px-4">
        <div className="container mx-auto">
          <Alert variant="destructive" className="bg-red-900/20 border-red-500/30">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Error</AlertTitle>
            <AlertDescription>{error}</AlertDescription>
          </Alert>
          <div className="mt-4 flex justify-center">
            <Button onClick={() => window.location.reload()}>Refresh Page</Button>
          </div>
        </div>
      </section>
    )
  }

  return (
    <section className="py-8 px-4">
      <div className="container mx-auto">
        {/* Data Source Indicator */}
        <div className="flex items-center justify-center mb-6">
          <div className="bg-gradient-to-r from-purple-500/20 to-purple-600/20 backdrop-blur-md border border-purple-300/30 rounded-full px-4 py-2 flex items-center gap-2">
            <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
            <span className="text-purple-200 font-orbitron text-sm">Live Data from PumpFun</span>
          </div>
        </div>

        {/* Sticky Filter Bar */}
        <div className="sticky top-0 z-10 bg-gradient-to-r from-purple-850/20 to-purple-750/20 backdrop-blur-md border border-purple-350/20 rounded-lg p-4 mb-8 shadow-[0_0_20px_rgba(168,85,247,0.1)]">
          <div className="flex flex-wrap gap-4 items-center justify-center">
            <div className="flex gap-2">
              <span className="text-purple-200 font-orbitron text-sm">Time:</span>
              <Button
                variant={timeFilter === "all" ? "default" : "outline"}
                size="sm"
                onClick={() => setTimeFilter("all")}
                className="font-orbitron text-xs"
              >
                All
              </Button>
              <Button
                variant={timeFilter === "recent" ? "default" : "outline"}
                size="sm"
                onClick={() => setTimeFilter("recent")}
                className="font-orbitron text-xs"
              >
                Recent
              </Button>
            </div>

            <div className="flex gap-2">
              <span className="text-purple-200 font-orbitron text-sm">MCAP:</span>
              <Button
                variant={volumeFilter === "all" ? "default" : "outline"}
                size="sm"
                onClick={() => setVolumeFilter("all")}
                className="font-orbitron text-xs"
              >
                All
              </Button>
              <Button
                variant={volumeFilter === "high" ? "default" : "outline"}
                size="sm"
                onClick={() => setVolumeFilter("high")}
                className="font-orbitron text-xs"
              >
                High
              </Button>
              <Button
                variant={volumeFilter === "low" ? "default" : "outline"}
                size="sm"
                onClick={() => setVolumeFilter("low")}
                className="font-orbitron text-xs"
              >
                Low
              </Button>
            </div>

            <div className="flex gap-2 flex-wrap justify-center">
              <span className="text-purple-200 font-orbitron text-sm">Theme:</span>
              <Button
                variant={themeFilter === "all" ? "default" : "outline"}
                size="sm"
                onClick={() => setThemeFilter("all")}
                className="font-orbitron text-xs"
              >
                All
              </Button>
              {["AI", "Meme", "DeFi", "NFT", "Community", "Infrastructure", "Gaming"].map((theme) => (
                <Button
                  key={theme}
                  variant={themeFilter === theme ? "default" : "outline"}
                  size="sm"
                  onClick={() => setThemeFilter(theme)}
                  className="font-orbitron text-xs"
                >
                  {theme}
                </Button>
              ))}
            </div>
          </div>
        </div>

        {/* Grid Header */}
        <div className="grid grid-cols-4 gap-4 mb-4 px-4 py-2 bg-gradient-to-r from-purple-550/10 to-purple-650/10 rounded-lg border border-purple-350/20">
          <div className="text-purple-200 font-orbitron font-semibold text-sm">Token</div>
          <div className="text-purple-200 font-orbitron font-semibold text-sm">Mint Time</div>
          <div className="text-purple-200 font-orbitron font-semibold text-sm">MCAP</div>
          <div className="text-purple-200 font-orbitron font-semibold text-sm">AI Score</div>
        </div>

        {/* Token Grid */}
        <div className="space-y-2 max-h-[calc(100vh-300px)] overflow-y-auto custom-scrollbar">
          {filteredTokens.length > 0 ? (
            filteredTokens.map((token) => (
              <div
                key={token.id}
                className={`
                  grid grid-cols-4 gap-4 p-4 
                  bg-gradient-to-r from-purple-600/10 to-purple-700/10 
                  backdrop-blur-sm 
                  border border-purple-400/30 
                  rounded-lg 
                  hover:border-purple-350/50 
                  hover:shadow-[0_0_15px_rgba(168,85,247,0.2)]
                  transition-all duration-300
                  ${token.isNew ? "animate-pulse shadow-[0_0_25px_rgba(168,85,247,0.4)] border-purple-450/60" : ""}
                `}
              >
                <div className="flex items-center gap-3">
                  <TokenImage symbol={token.symbol} imageUrl={token.imageUrl} theme={token.theme} isNew={token.isNew} />
                  <div>
                    <div className="text-purple-100 font-orbitron font-semibold text-sm flex items-center gap-1">
                      {token.symbol}
                      {token.isNew && <span className="text-xs text-green-400 font-bold">NEW!</span>}
                    </div>
                    <div className="text-purple-300/60 font-orbitron text-xs">{token.name}</div>
                  </div>
                </div>

                <div className="flex items-center">
                  <div className="text-purple-200 font-orbitron text-sm">{token.mintTime}</div>
                </div>

                <div className="flex items-center">
                  <div className="text-purple-100 font-orbitron font-semibold text-sm">
                    {formatVolume(token.volume)}
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <div className={`font-orbitron font-bold text-sm ${getScoreColor(token.aiScore)}`}>
                    {token.aiScore}
                  </div>
                  <Badge variant="outline" className={`text-xs font-orbitron ${getThemeColor(token.theme)}`}>
                    {token.theme}
                  </Badge>
                </div>
              </div>
            ))
          ) : (
            <div className="text-center py-8 text-purple-300 font-orbitron">
              No tokens match your current filters. Try adjusting your filters.
            </div>
          )}
        </div>

        {/* Scrolling Ticker Footer */}
        <div className="mt-8 bg-gradient-to-r from-purple-900/30 to-purple-800/30 backdrop-blur-sm border border-purple-300/20 rounded-lg overflow-hidden">
          <div className="py-3 whitespace-nowrap overflow-hidden relative">
            <div className="inline-block animate-scroll">
              <span className="text-purple-200 font-orbitron text-sm">
                🔥 PumpFun Trending: {tickerTokens.join(" • ")} • {tickerTokens.join(" • ")}
              </span>
            </div>
          </div>
        </div>

        {/* Enhanced Development Notice */}
        <div className="mt-6 flex justify-center">
          <div className="bg-gradient-to-r from-amber-500/20 to-orange-500/20 backdrop-blur-md border border-amber-400/40 rounded-lg px-4 py-3 shadow-[0_0_15px_rgba(245,158,11,0.2)]">
            <div className="flex items-center gap-3">
              <AlertTriangle className="h-5 w-5 text-amber-400 animate-pulse" />
              <div className="text-center">
                <div className="text-amber-200 font-orbitron font-semibold text-sm">🚧 VIEW ONLY MODE</div>
                <div className="text-amber-300/80 font-orbitron text-xs mt-1">
                  Application in Development - Trading Features Coming Soon
                </div>
              </div>
              <Eye className="h-4 w-4 text-amber-400" />
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
