"use client"

import { useState, useEffect } from "react"
import { MoonIcon } from "lucide-react"

interface LoadingScreenProps {
  onLoadingComplete?: () => void
}

export default function LoadingScreen({ onLoadingComplete }: LoadingScreenProps) {
  const [progress, setProgress] = useState(0)
  const [isVisible, setIsVisible] = useState(true)
  const [isContentReady, setIsContentReady] = useState(false)

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          // Wait a bit longer to ensure content is ready
          setTimeout(() => {
            setIsContentReady(true)
            onLoadingComplete?.()
            // Fade out after content is confirmed ready
            setTimeout(() => setIsVisible(false), 100)
          }, 500)
          return 100
        }
        return prev + Math.random() * 15 + 5 // Random increment between 5-20
      })
    }, 150)

    return () => clearInterval(interval)
  }, [onLoadingComplete])

  if (!isVisible) return null

  return (
    <div
      className={`fixed inset-0 z-50 bg-gradient-to-br from-[#0a0520] to-[#1a0f3a] flex items-center justify-center transition-opacity duration-500 ${
        isContentReady ? "opacity-0 pointer-events-none" : "opacity-100"
      }`}
    >
      {/* Animated stars background */}
      <div className="absolute inset-0">
        {[...Array(50)].map((_, i) => (
          <div
            key={i}
            className="absolute w-1 h-1 bg-purple-300 rounded-full animate-pulse"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 2}s`,
              animationDuration: `${2 + Math.random() * 2}s`,
            }}
          />
        ))}
      </div>

      <div className="text-center z-10">
        {/* Logo with glow effect */}
        <div className="mb-8 relative">
          <MoonIcon className="h-16 w-16 text-purple-300 mx-auto animate-spin" style={{ animationDuration: "3s" }} />
          <div className="absolute inset-0 h-16 w-16 mx-auto bg-purple-400/20 rounded-full blur-xl animate-pulse" />
        </div>

        {/* Title */}
        <h1 className="text-4xl font-bold font-orbitron bg-gradient-to-r from-purple-200 via-purple-300 to-purple-400 bg-clip-text text-transparent mb-4 animate-pulse">
          MoonCity AI
        </h1>

        {/* Loading text */}
        <p className="text-purple-100/80 font-orbitron text-lg mb-8">Initializing AI Systems...</p>

        {/* Progress bar */}
        <div className="w-80 mx-auto">
          <div className="bg-purple-900/30 rounded-full h-2 mb-4 overflow-hidden">
            <div
              className="bg-gradient-to-r from-purple-400 to-purple-600 h-full rounded-full transition-all duration-300 ease-out shadow-[0_0_10px_rgba(168,85,247,0.5)]"
              style={{ width: `${progress}%` }}
            />
          </div>
          <div className="text-purple-200 font-orbitron text-sm">{Math.round(progress)}% Complete</div>
        </div>

        {/* Loading messages */}
        <div className="mt-6 h-6">
          {progress < 30 && (
            <p className="text-purple-300/60 font-orbitron text-sm animate-fade-in">Loading market data...</p>
          )}
          {progress >= 30 && progress < 60 && (
            <p className="text-purple-300/60 font-orbitron text-sm animate-fade-in">Initializing AI models...</p>
          )}
          {progress >= 60 && progress < 90 && (
            <p className="text-purple-300/60 font-orbitron text-sm animate-fade-in">Connecting to blockchain...</p>
          )}
          {progress >= 90 && (
            <p className="text-purple-300/60 font-orbitron text-sm animate-fade-in">Ready to launch! 🚀</p>
          )}
        </div>
      </div>
    </div>
  )
}
