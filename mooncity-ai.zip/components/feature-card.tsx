import type { ReactNode } from "react"

interface FeatureCardProps {
  icon: ReactNode
  title: string
  description: string
  gradient?: string
  borderColor?: string
  glowColor?: string
}

export default function FeatureCard({
  icon,
  title,
  description,
  gradient = "from-purple-450/15 to-purple-550/15",
  borderColor = "border-purple-350/40",
  glowColor = "shadow-[0_0_15px_rgba(196,169,255,0.2)]",
}: FeatureCardProps) {
  return (
    <div
      className={`
      bg-gradient-to-br ${gradient} 
      backdrop-blur-md 
      p-8 
      rounded-lg 
      border ${borderColor}
      ${glowColor}
      hover:${glowColor.replace("0.2", "0.3")}
      transition-all 
      duration-300 
      hover:scale-[1.02]
      relative
      overflow-hidden
    `}
    >
      {/* Subtle animated border effect */}
      <div className="absolute inset-0 bg-gradient-to-r from-transparent via-purple-250/5 to-transparent -translate-x-full animate-[shimmer_4s_infinite] pointer-events-none" />

      <div
        className={`bg-gradient-to-br ${gradient} w-12 h-12 rounded-lg flex items-center justify-center mb-4 border ${borderColor}`}
      >
        {icon}
      </div>
      <h3 className="text-xl font-semibold font-orbitron text-purple-250 mb-2 drop-shadow-[0_0_5px_rgba(216,180,254,0.3)]">
        {title}
      </h3>
      <p className="text-purple-150/80 font-orbitron text-sm leading-relaxed drop-shadow-[0_0_3px_rgba(216,180,254,0.2)]">
        {description}
      </p>
    </div>
  )
}
