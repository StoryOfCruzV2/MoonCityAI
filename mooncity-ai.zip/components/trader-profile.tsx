import { BadgeCheckIcon, StarIcon, TrendingUpIcon, AwardIcon, ShieldCheckIcon, UsersIcon } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import Image from "next/image"

interface TraderStats {
  winRate: string
  avgReturn: string
  experience: string
  followers: string
}

interface TraderProfileProps {
  name: string
  handle: string
  role: string
  quote: string
  rating: number
  verified: boolean
  profileImage: string
  stats?: TraderStats
  badges?: string[]
  featured?: boolean
}

export default function TraderProfile({
  name,
  handle,
  role,
  quote,
  rating,
  verified = false,
  profileImage,
  stats,
  badges = [],
  featured = false,
}: TraderProfileProps) {
  return (
    <div
      className={`bg-gradient-to-r from-purple-550/10 to-purple-650/10 backdrop-blur-md border ${
        featured ? "border-purple-450/30" : "border-purple-350/20"
      } rounded-lg p-6 relative ${
        featured ? "shadow-[0_0_25px_rgba(168,85,247,0.2)]" : "shadow-[0_0_15px_rgba(168,85,247,0.1)]"
      } transition-all duration-300 hover:shadow-[0_0_30px_rgba(168,85,247,0.25)]`}
    >
      {featured && (
        <div className="absolute -top-3 -right-3">
          <Badge className="bg-gradient-to-r from-amber-400 to-amber-600 text-white border-0 shadow-lg">
            <AwardIcon className="h-3 w-3 mr-1" /> Top Trader
          </Badge>
        </div>
      )}

      <div className="flex items-start gap-4">
        {/* Profile Image with Status Indicator */}
        <div className="relative">
          <div
            className={`w-14 h-14 rounded-full overflow-hidden border-2 ${
              featured ? "border-amber-400" : "border-purple-400"
            }`}
          >
            <Image
              src={profileImage || "/placeholder.svg"}
              alt={name}
              width={56}
              height={56}
              className="object-cover"
            />
          </div>
          {verified && (
            <div className="absolute -bottom-1 -right-1 bg-blue-500 rounded-full p-0.5 border border-blue-300 shadow-lg">
              <BadgeCheckIcon className="h-4 w-4 text-white" />
            </div>
          )}
        </div>

        {/* Trader Info */}
        <div className="flex-1">
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center gap-1">
                <h3 className="text-purple-200 font-orbitron font-semibold text-base">{name}</h3>
                {verified && <BadgeCheckIcon className="h-4 w-4 text-blue-400" />}
              </div>
              <div className="flex items-center gap-1">
                <span className="text-purple-300/60 font-orbitron text-xs">{handle}</span>
                {role && (
                  <Badge variant="outline" className="text-[10px] h-4 px-1 ml-1 border-purple-400/30 text-purple-300">
                    {role}
                  </Badge>
                )}
              </div>
            </div>
            <div className="flex items-center gap-0.5">
              {[...Array(5)].map((_, i) => (
                <StarIcon
                  key={i}
                  className={`h-3 w-3 ${i < rating ? "text-yellow-400 fill-current" : "text-purple-700"}`}
                />
              ))}
            </div>
          </div>

          {/* Badges */}
          {badges && badges.length > 0 && (
            <div className="flex flex-wrap gap-1 mt-2">
              {badges.map((badge, index) => (
                <Badge
                  key={index}
                  variant="outline"
                  className="text-[10px] h-5 border-purple-450/20 bg-purple-550/10 text-purple-250"
                >
                  {badge}
                </Badge>
              ))}
            </div>
          )}

          {/* Quote */}
          <p className="text-purple-100/80 font-orbitron text-sm italic mt-3 leading-relaxed">{quote}</p>

          {/* Stats */}
          {stats && (
            <div className="grid grid-cols-2 gap-x-4 gap-y-1 mt-3 pt-3 border-t border-purple-350/10">
              <div className="flex items-center gap-1">
                <TrendingUpIcon className="h-3 w-3 text-green-400" />
                <span className="text-purple-200 font-orbitron text-xs">Win Rate:</span>
                <span className="text-green-400 font-orbitron text-xs font-semibold">{stats.winRate}</span>
              </div>
              <div className="flex items-center gap-1">
                <ShieldCheckIcon className="h-3 w-3 text-blue-400" />
                <span className="text-purple-200 font-orbitron text-xs">Experience:</span>
                <span className="text-blue-400 font-orbitron text-xs font-semibold">{stats.experience}</span>
              </div>
              <div className="flex items-center gap-1">
                <StarIcon className="h-3 w-3 text-yellow-400" />
                <span className="text-purple-200 font-orbitron text-xs">Avg Return:</span>
                <span className="text-yellow-400 font-orbitron text-xs font-semibold">{stats.avgReturn}</span>
              </div>
              <div className="flex items-center gap-1">
                <UsersIcon className="h-3 w-3 text-purple-400" />
                <span className="text-purple-200 font-orbitron text-xs">Followers:</span>
                <span className="text-purple-400 font-orbitron text-xs font-semibold">{stats.followers}</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
