"use client"

import { useState, useEffect } from "react"
import RollingCounter from "./rolling-counter"

export default function LiveMetrics() {
  const [totalVolume, setTotalVolume] = useState(2110000) // Start at 2.11M
  const [activeUsers, setActiveUsers] = useState(131)

  useEffect(() => {
    // Update total volume every 5 seconds (increase by a few thousand)
    const volumeInterval = setInterval(() => {
      setTotalVolume((prev) => {
        const increase = Math.floor(Math.random() * 5000) + 2000 // Random increase between 2000-7000
        return prev + increase
      })
    }, 5000)

    // Update active users every 6 seconds (random change between -9 to +9, but keep above 120)
    const usersInterval = setInterval(() => {
      setActiveUsers((prev) => {
        const change = Math.floor(Math.random() * 19) - 9 // Random between -9 and +9
        const newValue = prev + change
        // Keep users between 120 and 200 for realism
        return Math.max(120, Math.min(200, newValue))
      })
    }, 6000)

    return () => {
      clearInterval(volumeInterval)
      clearInterval(usersInterval)
    }
  }, [])

  // Format volume as currency with M/K suffixes
  const formatVolume = (volume: number) => {
    if (volume >= 1000000) {
      return `$${(volume / 1000000).toFixed(2)}M`
    }
    return `$${(volume / 1000).toFixed(0)}K`
  }

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
      <div className="text-center">
        <RollingCounter
          value={totalVolume}
          className="text-4xl font-bold font-orbitron text-green-400 mb-2"
          duration={1000}
          formatter={(val) => `${formatVolume(val)}+`}
        />
        <div className="text-purple-200 font-orbitron text-sm">Total Volume Tracked</div>
        <div className="text-xs text-green-300 font-orbitron mt-1 opacity-70">Live</div>
      </div>
      <div className="text-center">
        <RollingCounter
          value={activeUsers}
          className="text-4xl font-bold font-orbitron text-blue-400 mb-2"
          duration={600}
        />
        <div className="text-purple-200 font-orbitron text-sm">Active Users</div>
        <div className="text-xs text-blue-300 font-orbitron mt-1 opacity-70">Online Now</div>
      </div>
      <div className="text-center">
        <div className="text-4xl font-bold font-orbitron text-yellow-400 mb-2">98.7%</div>
        <div className="text-purple-200 font-orbitron text-sm">Success Rate</div>
        <div className="text-xs text-yellow-300 font-orbitron mt-1 opacity-70">Verified</div>
      </div>
      <div className="text-center">
        <div className="text-4xl font-bold font-orbitron text-purple-450 mb-2">24/7</div>
        <div className="text-purple-250 font-orbitron text-sm">Uptime</div>
        <div className="text-xs text-purple-350 font-orbitron mt-1 opacity-70">Guaranteed</div>
      </div>
    </div>
  )
}
