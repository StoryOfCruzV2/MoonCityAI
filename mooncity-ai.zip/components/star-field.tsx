"use client"

import { useEffect, useRef, useState } from "react"

interface StarFieldProps {
  onReady?: () => void
}

export default function StarField({ onReady }: StarFieldProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [isReady, setIsReady] = useState(false)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Set canvas to full screen with high DPI support for 4K/HD quality
    canvas.width = window.innerWidth
    canvas.height = window.innerHeight

    // Add high DPI support for enhanced visual quality
    const dpr = window.devicePixelRatio || 1
    canvas.width = window.innerWidth * dpr
    canvas.height = window.innerHeight * dpr
    canvas.style.width = window.innerWidth + "px"
    canvas.style.height = window.innerHeight + "px"
    ctx.scale(dpr, dpr)

    // Snowflake properties
    const snowflakes: {
      x: number
      y: number
      size: number
      opacity: number
      speedY: number
      speedX: number
      drift: number
      driftPhase: number
      driftSpeed: number
      rotation: number
      rotationSpeed: number
      type: number
    }[] = []
    const snowflakeCount = 120 // Increased count for better visual effect

    // Create snowflake shapes
    const drawSnowflake = (
      ctx: CanvasRenderingContext2D,
      x: number,
      y: number,
      size: number,
      opacity: number,
      rotation: number,
      type: number,
    ) => {
      ctx.save()
      ctx.translate(x, y)
      ctx.rotate(rotation)
      ctx.fillStyle = `rgba(255, 255, 255, ${opacity})`
      ctx.strokeStyle = `rgba(240, 248, 255, ${opacity * 0.8})`
      ctx.lineWidth = size / 10

      // Different snowflake types
      switch (type) {
        case 0: // Simple circle with inner detail
          ctx.beginPath()
          ctx.arc(0, 0, size, 0, Math.PI * 2)
          ctx.fill()

          // Inner detail
          ctx.beginPath()
          ctx.arc(0, 0, size * 0.5, 0, Math.PI * 2)
          ctx.fillStyle = `rgba(240, 248, 255, ${opacity * 0.9})`
          ctx.fill()
          break

        case 1: // Six-pointed star
          for (let i = 0; i < 6; i++) {
            ctx.beginPath()
            ctx.moveTo(0, 0)
            ctx.lineTo(0, size)
            ctx.stroke()
            ctx.rotate(Math.PI / 3)
          }

          // Center dot
          ctx.beginPath()
          ctx.arc(0, 0, size * 0.2, 0, Math.PI * 2)
          ctx.fill()
          break

        case 2: // Crystalline shape
          for (let i = 0; i < 6; i++) {
            ctx.beginPath()
            ctx.moveTo(0, 0)
            ctx.lineTo(0, size)

            // Add branches
            ctx.moveTo(0, size * 0.3)
            ctx.lineTo(size * 0.3, size * 0.5)

            ctx.moveTo(0, size * 0.3)
            ctx.lineTo(-size * 0.3, size * 0.5)

            ctx.moveTo(0, size * 0.6)
            ctx.lineTo(size * 0.2, size * 0.75)

            ctx.moveTo(0, size * 0.6)
            ctx.lineTo(-size * 0.2, size * 0.75)

            ctx.stroke()
            ctx.rotate(Math.PI / 3)
          }
          break

        case 3: // Simple dot with glow
        default:
          // Main snowflake
          ctx.beginPath()
          ctx.arc(0, 0, size * 0.5, 0, Math.PI * 2)
          ctx.fill()

          // Glow effect
          const gradient = ctx.createRadialGradient(0, 0, size * 0.2, 0, 0, size)
          gradient.addColorStop(0, `rgba(255, 255, 255, ${opacity * 0.8})`)
          gradient.addColorStop(1, `rgba(240, 248, 255, 0)`)

          ctx.fillStyle = gradient
          ctx.beginPath()
          ctx.arc(0, 0, size, 0, Math.PI * 2)
          ctx.fill()
          break
      }

      ctx.restore()
    }

    // Create snowfall distribution across the entire screen
    const createSnowfallDistribution = () => {
      for (let i = 0; i < snowflakeCount; i++) {
        // Distribute snowflakes randomly across the entire width and at various heights
        const x = Math.random() * window.innerWidth
        const y = Math.random() * window.innerHeight

        // Varied sizes for different snowflakes
        const size = Math.random() * 4 + 2 // Size between 2-6px

        // Varied opacity for depth perception
        const opacity = Math.random() * 0.7 + 0.3

        // Slower falling speed with variation - reduced from previous version
        const speedY = Math.random() * 0.4 + 0.25 // Vertical speed between 0.25-0.65

        // Horizontal drift parameters
        const drift = Math.random() * 1.5 + 0.5 // Max drift distance
        const driftPhase = Math.random() * Math.PI * 2 // Random starting phase
        const driftSpeed = Math.random() * 0.02 + 0.005 // Drift oscillation speed

        // Rotation parameters
        const rotation = Math.random() * Math.PI * 2 // Random starting rotation
        const rotationSpeed = (Math.random() * 0.02 + 0.005) * (Math.random() > 0.5 ? 1 : -1) // Random rotation speed and direction

        // Snowflake type (0-3)
        const type = Math.floor(Math.random() * 4)

        snowflakes.push({
          x,
          y,
          size,
          opacity,
          speedY,
          speedX: 0, // Initial horizontal speed (will be updated by drift)
          drift,
          driftPhase,
          driftSpeed,
          rotation,
          rotationSpeed,
          type,
        })
      }
    }

    // Create snowflakes
    createSnowfallDistribution()

    // Signal that StarField is ready after initial setup
    setTimeout(() => {
      setIsReady(true)
      onReady?.()
    }, 100)

    // Animation function for snowfall effect
    function animate() {
      ctx.clearRect(0, 0, canvas.width, canvas.height)

      // Draw and update snowflakes
      snowflakes.forEach((snowflake, index) => {
        // Update horizontal drift using sine wave
        snowflake.driftPhase += snowflake.driftSpeed
        if (snowflake.driftPhase > Math.PI * 2) {
          snowflake.driftPhase -= Math.PI * 2
        }

        // Calculate horizontal speed from drift
        snowflake.speedX = Math.sin(snowflake.driftPhase) * snowflake.drift * 0.05

        // Update rotation
        snowflake.rotation += snowflake.rotationSpeed

        // Draw snowflake
        drawSnowflake(
          ctx,
          snowflake.x,
          snowflake.y,
          snowflake.size,
          snowflake.opacity,
          snowflake.rotation,
          snowflake.type,
        )

        // Move snowflake
        snowflake.y += snowflake.speedY
        snowflake.x += snowflake.speedX

        // Reset snowflake position when it goes off screen
        if (snowflake.y > window.innerHeight + 20) {
          snowflake.y = -20 // Reset to top
          snowflake.x = Math.random() * window.innerWidth // Random horizontal position

          // Occasionally refresh other properties for variety
          if (Math.random() > 0.8) {
            snowflake.size = Math.random() * 4 + 2
            snowflake.drift = Math.random() * 1.5 + 0.5
            snowflake.type = Math.floor(Math.random() * 4)
          }
        }

        // Wrap horizontally
        if (snowflake.x > window.innerWidth + 20) {
          snowflake.x = -20
        } else if (snowflake.x < -20) {
          snowflake.x = window.innerWidth + 20
        }
      })

      requestAnimationFrame(animate)
    }

    animate()

    // Handle resize with snowfall redistribution
    const handleResize = () => {
      const dpr = window.devicePixelRatio || 1
      canvas.width = window.innerWidth * dpr
      canvas.height = window.innerHeight * dpr
      canvas.style.width = window.innerWidth + "px"
      canvas.style.height = window.innerHeight + "px"
      ctx.scale(dpr, dpr)

      // Recreate snowfall distribution on resize
      snowflakes.length = 0
      createSnowfallDistribution()
    }

    window.addEventListener("resize", handleResize)

    return () => {
      window.removeEventListener("resize", handleResize)
    }
  }, [onReady])

  return (
    <canvas
      ref={canvasRef}
      className={`fixed top-0 left-0 w-full h-full pointer-events-none z-0 transition-opacity duration-300 ${
        isReady ? "opacity-100" : "opacity-0"
      }`}
      style={{ zIndex: 0 }}
    />
  )
}
