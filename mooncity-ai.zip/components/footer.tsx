import { MoonIcon, MessageCircleIcon, MailIcon, FileTextIcon, ShieldIcon, UsersIcon } from "lucide-react"
import Link from "next/link"

export default function Footer() {
  const currentYear = new Date().getFullYear()

  return (
    <footer className="bg-[#0f0f23] border-t border-purple-350/20">
      <div className="container mx-auto px-4 py-16">
        {/* Main Footer Content */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
          {/* Company Info & Mission */}
          <div className="md:col-span-2 space-y-6">
            <div className="flex items-center gap-2 mb-4">
              <MoonIcon className="h-7 w-7 text-purple-300" />
              <span className="text-2xl font-bold font-orbitron text-white">MoonCity AI</span>
            </div>
            <p className="text-gray-300 font-orbitron text-sm leading-relaxed max-w-md">
              Advanced Solana sniping agents powered by real-time data and AI technology. We democratize access to
              professional-grade trading tools for the crypto community.
            </p>

            {/* Mission Statement */}
            <div className="bg-gradient-to-r from-purple-550/10 to-purple-650/10 border border-purple-350/20 rounded-lg p-4">
              <h4 className="text-purple-200 font-orbitron font-semibold text-sm mb-2 flex items-center gap-2">
                <span className="text-lg">🚀</span> Our Mission
              </h4>
              <p className="text-purple-100/80 font-orbitron text-xs leading-relaxed">
                To level the playing field in crypto trading by providing AI-powered tools that help individual traders
                compete with institutional players and discover profitable opportunities before they go mainstream.
              </p>
            </div>

            {/* Social Media */}
            <div className="space-y-3">
              <h4 className="text-white font-orbitron font-semibold text-sm">Follow Us</h4>
              <div className="flex items-center gap-4">
                <a
                  href="https://t.me/mooncitylink"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 bg-gradient-to-r from-blue-550/20 to-blue-650/20 border border-blue-450/30 rounded-lg px-3 py-2 text-blue-350 hover:text-blue-250 hover:bg-blue-550/30 transition-all duration-300"
                >
                  <MessageCircleIcon className="h-4 w-4" />
                  <span className="font-orbitron text-xs">Telegram</span>
                </a>
                <a
                  href="https://x.com/MoonCityAI"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 bg-gradient-to-r from-sky-500/20 to-sky-600/20 border border-sky-400/30 rounded-lg px-3 py-2 text-sky-300 hover:text-sky-200 hover:bg-sky-500/30 transition-all duration-300"
                >
                  <svg className="h-4 w-4" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
                  </svg>
                  <span className="font-orbitron text-xs">Twitter</span>
                </a>
              </div>
            </div>
          </div>

          {/* Platform Links */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold font-orbitron text-white">Platform</h3>
            <ul className="space-y-3">
              <li>
                <Link
                  href="/live-coins"
                  className="text-gray-400 hover:text-purple-300 font-orbitron text-sm transition-colors flex items-center gap-2"
                >
                  <span className="w-1 h-1 bg-purple-400 rounded-full"></span>
                  Live Token Tracker
                </Link>
              </li>
              <li>
                <Link
                  href="/trending-themes"
                  className="text-gray-400 hover:text-purple-300 font-orbitron text-sm transition-colors flex items-center gap-2"
                >
                  <span className="w-1 h-1 bg-purple-400 rounded-full"></span>
                  Trending Themes
                </Link>
              </li>
              <li>
                <Link
                  href="/create-agent"
                  className="text-gray-400 hover:text-purple-300 font-orbitron text-sm transition-colors flex items-center gap-2"
                >
                  <span className="w-1 h-1 bg-purple-400 rounded-full"></span>
                  Create Agent
                </Link>
              </li>
              <li>
                <Link
                  href="/token-distribution"
                  className="text-gray-400 hover:text-purple-300 font-orbitron text-sm transition-colors flex items-center gap-2"
                >
                  <span className="w-1 h-1 bg-purple-400 rounded-full"></span>
                  Token Distribution
                </Link>
              </li>
              <li>
                <Link
                  href="/whitepaper"
                  className="text-gray-400 hover:text-purple-300 font-orbitron text-sm transition-colors flex items-center gap-2"
                >
                  <span className="w-1 h-1 bg-purple-400 rounded-full"></span>
                  Whitepaper
                </Link>
              </li>
            </ul>
          </div>

          {/* Company & Legal Links */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold font-orbitron text-white">Company</h3>
            <ul className="space-y-3">
              <li>
                <a
                  href="#"
                  className="text-gray-400 hover:text-purple-300 font-orbitron text-sm transition-colors flex items-center gap-2"
                >
                  <UsersIcon className="h-3 w-3" />
                  About Us
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="text-gray-400 hover:text-purple-300 font-orbitron text-sm transition-colors flex items-center gap-2"
                >
                  <MailIcon className="h-3 w-3" />
                  Contact
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="text-gray-400 hover:text-purple-300 font-orbitron text-sm transition-colors flex items-center gap-2"
                >
                  <ShieldIcon className="h-3 w-3" />
                  Privacy Policy
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="text-gray-400 hover:text-purple-300 font-orbitron text-sm transition-colors flex items-center gap-2"
                >
                  <FileTextIcon className="h-3 w-3" />
                  Terms of Service
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="text-gray-400 hover:text-purple-300 font-orbitron text-sm transition-colors flex items-center gap-2"
                >
                  <span className="w-3 h-3 bg-green-400 rounded-full"></span>
                  Security
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="text-gray-400 hover:text-purple-300 font-orbitron text-sm transition-colors flex items-center gap-2"
                >
                  <span className="w-3 h-3 bg-blue-400 rounded-full"></span>
                  Help Center
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Trust Indicators */}
        <div className="border-t border-purple-350/20 pt-8 mb-8">
          <div className="flex flex-wrap justify-center items-center gap-8 text-purple-350/60 font-orbitron text-xs">
            <div className="flex items-center gap-2">
              <ShieldIcon className="h-4 w-4 text-green-400" />
              <span>Security Audited</span>
            </div>
            <div className="flex items-center gap-2">
              <FileTextIcon className="h-4 w-4 text-blue-400" />
              <span>SOC2 Compliant</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 bg-gradient-to-r from-purple-400 to-purple-600 rounded"></div>
              <span>Solana Verified</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 bg-gradient-to-r from-green-400 to-green-600 rounded"></div>
              <span>99.9% Uptime</span>
            </div>
          </div>
        </div>

        {/* Bottom Copyright */}
        <div className="border-t border-gray-700 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="text-gray-400 font-orbitron text-sm">© {currentYear} MoonCity AI. All rights reserved.</div>
            <div className="flex items-center gap-6 text-gray-400 font-orbitron text-xs">
              <span>Made with ❤️ for the Solana community</span>
              <span className="hidden md:block">•</span>
              <span className="hidden md:block">Powered by AI & Blockchain</span>
            </div>
          </div>
        </div>

        {/* Disclaimer */}
        <div className="mt-8 p-4 bg-purple-500/5 border border-purple-300/10 rounded-lg">
          <p className="text-purple-100/50 font-orbitron text-xs leading-relaxed text-center">
            <strong>Important:</strong> Cryptocurrency trading involves risk. Past performance does not guarantee future
            results. Always do your own research and never invest more than you can afford to lose. MoonCity AI provides
            tools and information but does not provide financial advice.
          </p>
        </div>
      </div>
    </footer>
  )
}
