"use client"

import { useEffect, useRef } from "react"

interface MoonTextureProps {
  size?: number
  position?: {
    top?: string
    right?: string
    bottom?: string
    left?: string
  }
  zIndex?: number
}

export default function MoonTexture({
  size = 180,
  position = { top: "40px", right: "40px" },
  zIndex = 0,
}: MoonTextureProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Set canvas dimensions with high DPI support
    const dpr = window.devicePixelRatio || 1
    canvas.width = size * dpr
    canvas.height = size * dpr
    canvas.style.width = `${size}px`
    canvas.style.height = `${size}px`
    ctx.scale(dpr, dpr)

    // Draw moon base
    const centerX = size / 2
    const centerY = size / 2
    const radius = size / 2 - 2

    // Create gradient for the moon
    const gradient = ctx.createRadialGradient(
      centerX - radius * 0.2,
      centerY - radius * 0.2,
      radius * 0.1,
      centerX,
      centerY,
      radius,
    )
    gradient.addColorStop(0, "rgba(255, 255, 255, 1)")
    gradient.addColorStop(0.85, "rgba(230, 230, 240, 1)")
    gradient.addColorStop(1, "rgba(220, 220, 235, 0.8)")

    // Draw the moon circle
    ctx.beginPath()
    ctx.arc(centerX, centerY, radius, 0, Math.PI * 2)
    ctx.fillStyle = gradient
    ctx.fill()

    // Add subtle glow
    const glowGradient = ctx.createRadialGradient(centerX, centerY, radius * 0.9, centerX, centerY, radius * 1.2)
    glowGradient.addColorStop(0, "rgba(255, 255, 255, 0.3)")
    glowGradient.addColorStop(1, "rgba(255, 255, 255, 0)")

    ctx.beginPath()
    ctx.arc(centerX, centerY, radius * 1.2, 0, Math.PI * 2)
    ctx.fillStyle = glowGradient
    ctx.fill()

    // Enhanced crater system
    const addCrater = (x: number, y: number, size: number, depth: number, hasRim = false) => {
      // Validate inputs to prevent non-finite values
      if (!isFinite(x) || !isFinite(y) || !isFinite(size) || size <= 0) return

      // Main crater shadow
      const craterGradient = ctx.createRadialGradient(x, y, 0, x, y, size)
      craterGradient.addColorStop(0, `rgba(180, 180, 200, ${depth})`)
      craterGradient.addColorStop(0.6, `rgba(200, 200, 220, ${depth * 0.7})`)
      craterGradient.addColorStop(0.9, `rgba(220, 220, 230, ${depth * 0.3})`)
      craterGradient.addColorStop(1, "rgba(230, 230, 240, 0)")

      ctx.beginPath()
      ctx.arc(x, y, size, 0, Math.PI * 2)
      ctx.fillStyle = craterGradient
      ctx.fill()

      // Add crater rim if specified
      if (hasRim) {
        const rimGradient = ctx.createRadialGradient(x, y, size * 0.8, x, y, size * 1.2)
        rimGradient.addColorStop(0, "rgba(255, 255, 255, 0)")
        rimGradient.addColorStop(0.7, `rgba(245, 245, 250, ${depth * 0.4})`)
        rimGradient.addColorStop(1, "rgba(255, 255, 255, 0)")

        ctx.beginPath()
        ctx.arc(x, y, size * 1.2, 0, Math.PI * 2)
        ctx.fillStyle = rimGradient
        ctx.fill()
      }

      // Add central peak for larger craters
      if (size > radius * 0.08) {
        const peakGradient = ctx.createRadialGradient(x, y, 0, x, y, size * 0.3)
        peakGradient.addColorStop(0, `rgba(250, 250, 255, ${depth * 0.6})`)
        peakGradient.addColorStop(1, "rgba(240, 240, 250, 0)")

        ctx.beginPath()
        ctx.arc(x, y, size * 0.3, 0, Math.PI * 2)
        ctx.fillStyle = peakGradient
        ctx.fill()
      }
    }

    // Generate major craters with rims
    const majorCraters = 8
    for (let i = 0; i < majorCraters; i++) {
      const angle = Math.random() * Math.PI * 2
      const distance = Math.random() * radius * 0.7
      const x = centerX + Math.cos(angle) * distance
      const y = centerY + Math.sin(angle) * distance

      const craterSize = Math.random() * (radius * 0.2) + radius * 0.08
      const depth = Math.random() * 0.5 + 0.3

      addCrater(x, y, craterSize, depth, true)
    }

    // Generate medium craters
    const mediumCraters = 25
    for (let i = 0; i < mediumCraters; i++) {
      const angle = Math.random() * Math.PI * 2
      const distance = Math.random() * radius * 0.85
      const x = centerX + Math.cos(angle) * distance
      const y = centerY + Math.sin(angle) * distance

      const craterSize = Math.random() * (radius * 0.12) + radius * 0.03
      const depth = Math.random() * 0.4 + 0.2

      addCrater(x, y, craterSize, depth, Math.random() > 0.7)
    }

    // Generate small craters
    const smallCraters = 45
    for (let i = 0; i < smallCraters; i++) {
      const angle = Math.random() * Math.PI * 2
      const distance = Math.random() * radius * 0.9
      const x = centerX + Math.cos(angle) * distance
      const y = centerY + Math.sin(angle) * distance

      const craterSize = Math.random() * (radius * 0.06) + radius * 0.01
      const depth = Math.random() * 0.3 + 0.1

      addCrater(x, y, craterSize, depth)
    }

    // Add ray systems (bright streaks from impact craters)
    const addRaySystem = (x: number, y: number, rayCount: number, rayLength: number) => {
      // Validate inputs
      if (!isFinite(x) || !isFinite(y) || !isFinite(rayLength) || rayLength <= 0) return

      for (let i = 0; i < rayCount; i++) {
        const angle = (Math.PI * 2 * i) / rayCount + Math.random() * 0.3
        const endX = x + Math.cos(angle) * rayLength
        const endY = y + Math.sin(angle) * rayLength

        // Validate end points
        if (!isFinite(endX) || !isFinite(endY)) continue

        // Create gradient along the ray
        const rayGradient = ctx.createLinearGradient(x, y, endX, endY)
        rayGradient.addColorStop(0, "rgba(255, 255, 255, 0.15)")
        rayGradient.addColorStop(0.3, "rgba(250, 250, 255, 0.08)")
        rayGradient.addColorStop(1, "rgba(245, 245, 250, 0)")

        ctx.beginPath()
        ctx.moveTo(x, y)
        ctx.lineTo(endX, endY)
        ctx.strokeStyle = rayGradient
        ctx.lineWidth = Math.random() * 2 + 1
        ctx.stroke()
      }
    }

    // Add a few ray systems from major craters
    for (let i = 0; i < 3; i++) {
      const angle = Math.random() * Math.PI * 2
      const distance = Math.random() * radius * 0.5
      const x = centerX + Math.cos(angle) * distance
      const y = centerY + Math.sin(angle) * distance

      addRaySystem(x, y, Math.floor(Math.random() * 6) + 4, radius * (Math.random() * 0.4 + 0.3))
    }

    // Enhanced surface texture with varied patterns
    for (let i = 0; i < 3500; i++) {
      const angle = Math.random() * Math.PI * 2
      const distance = Math.random() * radius

      // Skip if too close to edge for a smoother edge
      if (distance > radius * 0.92) continue

      const x = centerX + Math.cos(angle) * distance
      const y = centerY + Math.sin(angle) * distance

      // Validate coordinates
      if (!isFinite(x) || !isFinite(y)) continue

      // Create varied texture patterns
      const textureType = Math.random()

      if (textureType < 0.7) {
        // Regular tiny dots
        const brightness = Math.random() * 40 - 20
        const alpha = Math.random() * 0.08 + 0.01

        ctx.beginPath()
        ctx.arc(x, y, Math.random() * 0.8 + 0.2, 0, Math.PI * 2)
        ctx.fillStyle = `rgba(${220 + brightness}, ${220 + brightness}, ${235 + brightness}, ${alpha})`
        ctx.fill()
      } else if (textureType < 0.85) {
        // Slightly larger texture spots
        const brightness = Math.random() * 30 - 15
        const alpha = Math.random() * 0.06 + 0.02

        ctx.beginPath()
        ctx.arc(x, y, Math.random() * 1.5 + 0.5, 0, Math.PI * 2)
        ctx.fillStyle = `rgba(${210 + brightness}, ${210 + brightness}, ${225 + brightness}, ${alpha})`
        ctx.fill()
      } else {
        // Bright highlights
        const alpha = Math.random() * 0.04 + 0.01

        ctx.beginPath()
        ctx.arc(x, y, Math.random() * 0.6 + 0.3, 0, Math.PI * 2)
        ctx.fillStyle = `rgba(255, 255, 255, ${alpha})`
        ctx.fill()
      }
    }

    // Enhanced maria (dark areas) with more realistic shapes
    const addMaria = (x: number, y: number, size: number, irregularity = 0.2) => {
      // Validate inputs
      if (!isFinite(x) || !isFinite(y) || !isFinite(size) || size <= 0) return

      const mariaGradient = ctx.createRadialGradient(x, y, 0, x, y, size)
      mariaGradient.addColorStop(0, "rgba(160, 160, 190, 0.2)")
      mariaGradient.addColorStop(0.5, "rgba(180, 180, 210, 0.12)")
      mariaGradient.addColorStop(0.8, "rgba(190, 190, 210, 0.06)")
      mariaGradient.addColorStop(1, "rgba(200, 200, 220, 0)")

      // Create irregular shape
      ctx.beginPath()
      const points = 16
      for (let i = 0; i <= points; i++) {
        const angle = (i / points) * Math.PI * 2
        const variation = 1 + (Math.random() - 0.5) * irregularity
        const pointX = x + Math.cos(angle) * size * variation
        const pointY = y + Math.sin(angle) * size * variation

        // Validate point coordinates
        if (!isFinite(pointX) || !isFinite(pointY)) continue

        if (i === 0) {
          ctx.moveTo(pointX, pointY)
        } else {
          ctx.lineTo(pointX, pointY)
        }
      }
      ctx.closePath()
      ctx.fillStyle = mariaGradient
      ctx.fill()
    }

    // Add larger maria with irregular shapes
    for (let i = 0; i < 4; i++) {
      const angle = Math.random() * Math.PI * 2
      const distance = Math.random() * radius * 0.6
      const x = centerX + Math.cos(angle) * distance
      const y = centerY + Math.sin(angle) * distance
      const mariaSize = Math.random() * (radius * 0.35) + radius * 0.15

      addMaria(x, y, mariaSize, 0.3)
    }

    // Add smaller, more irregular maria
    for (let i = 0; i < 8; i++) {
      const angle = Math.random() * Math.PI * 2
      const distance = Math.random() * radius * 0.8
      const x = centerX + Math.cos(angle) * distance
      const y = centerY + Math.sin(angle) * distance
      const mariaSize = Math.random() * (radius * 0.2) + radius * 0.08

      addMaria(x, y, mariaSize, 0.4)
    }

    // Add mountain ranges (ridges) - Fixed to prevent non-finite values
    const addMountainRange = (startX: number, startY: number, endX: number, endY: number, height: number) => {
      // Validate all inputs
      if (
        !isFinite(startX) ||
        !isFinite(startY) ||
        !isFinite(endX) ||
        !isFinite(endY) ||
        !isFinite(height) ||
        height <= 0
      ) {
        return
      }

      const distance = Math.sqrt((endX - startX) ** 2 + (endY - startY) ** 2)

      // Validate distance calculation
      if (!isFinite(distance) || distance <= 0) return

      const steps = Math.max(1, Math.floor(distance / 3)) // Ensure at least 1 step

      for (let i = 0; i <= steps; i++) {
        const t = i / steps
        const x = startX + (endX - startX) * t
        const y = startY + (endY - startY) * t

        // Add some randomness to the ridge
        const offsetX = (Math.random() - 0.5) * 4
        const offsetY = (Math.random() - 0.5) * 4

        const finalX = x + offsetX
        const finalY = y + offsetY

        // Validate final coordinates and height
        if (!isFinite(finalX) || !isFinite(finalY)) continue

        const ridgeGradient = ctx.createRadialGradient(finalX, finalY, 0, finalX, finalY, height)
        ridgeGradient.addColorStop(0, "rgba(255, 255, 255, 0.1)")
        ridgeGradient.addColorStop(0.5, "rgba(240, 240, 250, 0.06)")
        ridgeGradient.addColorStop(1, "rgba(230, 230, 240, 0)")

        ctx.beginPath()
        ctx.arc(finalX, finalY, height, 0, Math.PI * 2)
        ctx.fillStyle = ridgeGradient
        ctx.fill()
      }
    }

    // Add a few mountain ranges with better validation
    for (let i = 0; i < 5; i++) {
      const startAngle = Math.random() * Math.PI * 2
      const endAngle = startAngle + (Math.random() - 0.5) * Math.PI
      const distance1 = Math.random() * radius * 0.7
      const distance2 = Math.random() * radius * 0.7

      const startX = centerX + Math.cos(startAngle) * distance1
      const startY = centerY + Math.sin(startAngle) * distance1
      const endX = centerX + Math.cos(endAngle) * distance2
      const endY = centerY + Math.sin(endAngle) * distance2
      const height = Math.random() * 3 + 2

      // Only add mountain range if all values are valid
      if (isFinite(startX) && isFinite(startY) && isFinite(endX) && isFinite(endY) && isFinite(height)) {
        addMountainRange(startX, startY, endX, endY, height)
      }
    }
  }, [size])

  return (
    <canvas
      ref={canvasRef}
      className="fixed pointer-events-none"
      style={{
        width: `${size}px`,
        height: `${size}px`,
        top: position.top || "auto",
        right: position.right || "auto",
        bottom: position.bottom || "auto",
        left: position.left || "auto",
        zIndex,
      }}
    />
  )
}
