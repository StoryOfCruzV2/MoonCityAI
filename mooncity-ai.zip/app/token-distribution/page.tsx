import { Button } from "@/components/ui/button"
import { MoonIcon, Link2Icon, PieChartIcon, CoinsIcon, CalendarIcon, UsersIcon } from "lucide-react"
import StarField from "@/components/star-field"
import Link from "next/link"
import Footer from "@/components/footer"

export default function TokenDistributionPage() {
  // Token allocation data
  const tokenAllocation = [
    { name: "Public Sale", percentage: 30, color: "#c4b5fd" },
    { name: "Team & Advisors", percentage: 20, color: "#a78bfa" },
    { name: "Ecosystem Development", percentage: 25, color: "#8b5cf6" },
    { name: "Treasury", percentage: 15, color: "#7c3aed" },
    { name: "Marketing & Partnerships", percentage: 10, color: "#d8b4fe" },
  ]

  // Calculate pie chart segments with percentage labels
  const createPieChart = () => {
    let startAngle = 0
    return tokenAllocation.map((segment, index) => {
      const angle = (segment.percentage / 100) * 360
      const endAngle = startAngle + angle

      // Calculate the SVG arc path
      const x1 = 100 + 80 * Math.cos(((startAngle - 90) * Math.PI) / 180)
      const y1 = 100 + 80 * Math.sin(((startAngle - 90) * Math.PI) / 180)
      const x2 = 100 + 80 * Math.cos(((endAngle - 90) * Math.PI) / 180)
      const y2 = 100 + 80 * Math.sin(((endAngle - 90) * Math.PI) / 180)

      // Calculate label position (middle of the segment)
      const labelAngle = startAngle + angle / 2 - 90
      const labelRadius = 60 // Position labels closer to center
      const labelX = 100 + labelRadius * Math.cos((labelAngle * Math.PI) / 180)
      const labelY = 100 + labelRadius * Math.sin((labelAngle * Math.PI) / 180)

      // Determine if the arc should be drawn as a large arc
      const largeArcFlag = angle > 180 ? 1 : 0

      // Create the SVG path
      const path = `M 100 100 L ${x1} ${y1} A 80 80 0 ${largeArcFlag} 1 ${x2} ${y2} Z`

      // Store the current end angle as the next start angle
      const currentStartAngle = startAngle
      startAngle = endAngle

      return (
        <g key={index}>
          <path
            d={path}
            fill={segment.color}
            stroke="#0f0f23"
            strokeWidth="2"
            className="hover:opacity-90 transition-opacity cursor-pointer"
            data-segment={segment.name}
            data-percentage={segment.percentage}
          />
          {/* Percentage label */}
          <text
            x={labelX}
            y={labelY}
            textAnchor="middle"
            dominantBaseline="middle"
            fill="white"
            className="text-xs font-orbitron font-bold drop-shadow-lg"
            style={{ textShadow: "1px 1px 2px rgba(0,0,0,0.8)" }}
          >
            {segment.percentage}%
          </text>
        </g>
      )
    })
  }

  return (
    <div className="relative min-h-screen overflow-hidden bg-gradient-to-br from-[#0a0520] to-[#1a0f3a]">
      {/* Star background */}
      <StarField />

      {/* Moon graphic with subtle glow */}
      <div className="absolute top-8 right-8 w-[150px] h-[150px] rounded-full bg-gradient-to-br from-purple-300/30 to-purple-400/20 shadow-[0_0_40px_rgba(196,169,255,0.4)] blur-sm hidden md:block" />
      <div className="absolute top-10 right-10 w-[110px] h-[110px] rounded-full bg-gradient-to-br from-purple-200/40 to-purple-300/30 shadow-[0_0_25px_rgba(216,180,254,0.5)] hidden md:block" />

      <div className="container mx-auto px-4">
        {/* Navigation with subtle effects */}
        <header className="flex items-center justify-between py-6">
          <div className="flex items-center gap-2">
            <Link href="/" className="flex items-center gap-2">
              <MoonIcon className="h-6 w-6 text-purple-300 drop-shadow-[0_0_5px_rgba(196,169,255,0.6)]" />
              <span className="text-xl font-bold font-orbitron text-purple-300 drop-shadow-[0_0_5px_rgba(196,169,255,0.6)]">
                MoonCity AI
              </span>
            </Link>
          </div>

          <nav className="hidden md:flex items-center gap-6">
            <Link href="/">
              <Button
                variant="link"
                className="text-purple-100 hover:text-purple-200 font-orbitron border border-transparent hover:border-purple-300/30 hover:shadow-[0_0_10px_rgba(196,169,255,0.2)] transition-all duration-300"
              >
                Home
              </Button>
            </Link>
            <Link href="/live-coins">
              <Button
                variant="link"
                className="text-purple-100 hover:text-purple-200 font-orbitron border border-transparent hover:border-purple-300/30 hover:shadow-[0_0_10px_rgba(196,169,255,0.2)] transition-all duration-300"
              >
                Live Coins
              </Button>
            </Link>
            <Link href="/whitepaper">
              <Button
                variant="link"
                className="text-purple-100 hover:text-purple-200 font-orbitron border border-transparent hover:border-purple-300/30 hover:shadow-[0_0_10px_rgba(196,169,255,0.2)] transition-all duration-300"
              >
                Whitepaper
              </Button>
            </Link>
            <Link href="/token-distribution">
              <Button
                variant="link"
                className="text-purple-100 hover:text-purple-200 font-orbitron border border-transparent hover:border-purple-300/30 hover:shadow-[0_0_10px_rgba(196,169,255,0.2)] transition-all duration-300"
              >
                Token Distribution
              </Button>
            </Link>
          </nav>

          <div className="flex items-center gap-2">
            <a href="https://t.me/mooncitylink" target="_blank" rel="noopener noreferrer">
              <Button className="bg-gradient-to-r from-sky-400 to-sky-500 hover:from-sky-500 hover:to-sky-600 text-white border border-sky-300/50 shadow-[0_0_15px_rgba(56,189,248,0.3)] hover:shadow-[0_0_20px_rgba(56,189,248,0.4)] transition-all duration-300 font-orbitron">
                <Link2Icon className="mr-2 h-4 w-4" />
                Telegram
              </Button>
            </a>
            <a href="https://x.com/MoonCityAI" target="_blank" rel="noopener noreferrer">
              <Button className="bg-gradient-to-r from-sky-500 to-sky-600 hover:from-sky-600 hover:to-sky-700 text-white border border-sky-300/50 shadow-[0_0_15px_rgba(14,165,233,0.3)] hover:shadow-[0_0_20px_rgba(14,165,233,0.4)] transition-all duration-300 font-orbitron">
                <svg className="mr-2 h-4 w-4" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
                </svg>
                Twitter
              </Button>
            </a>
          </div>
        </header>

        {/* Token Distribution Header */}
        <div className="py-12 text-center">
          <h1 className="text-4xl md:text-6xl font-bold font-orbitron bg-gradient-to-r from-purple-200 via-purple-300 to-purple-400 bg-clip-text text-transparent leading-tight max-w-4xl mx-auto drop-shadow-[0_0_15px_rgba(196,169,255,0.4)]">
            Token Distribution
          </h1>
          <p className="mt-4 text-purple-100 max-w-2xl mx-auto font-orbitron text-lg drop-shadow-[0_0_5px_rgba(216,180,254,0.3)]">
            MOON token allocation, vesting schedule, and utility
          </p>
        </div>

        {/* Token Distribution Content */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          {/* Token Allocation */}
          <div className="bg-gradient-to-r from-purple-900/30 to-purple-800/30 backdrop-blur-md border border-purple-300/20 rounded-lg p-6 shadow-[0_0_20px_rgba(168,85,247,0.1)]">
            <div className="flex items-center gap-2 mb-6">
              <PieChartIcon className="h-6 w-6 text-purple-300" />
              <h2 className="text-2xl font-bold font-orbitron text-purple-200">Token Allocation</h2>
            </div>

            {/* Pie Chart */}
            <div className="flex flex-col md:flex-row items-center justify-center gap-8 mb-8">
              <div className="relative w-[200px] h-[200px]">
                <svg viewBox="0 0 200 200" className="w-full h-full drop-shadow-[0_0_10px_rgba(196,169,255,0.3)]">
                  {createPieChart()}
                  {/* Center circle for better aesthetics */}
                  <circle cx="100" cy="100" r="40" fill="#0f0f23" className="opacity-80" />
                  <text x="100" y="95" textAnchor="middle" fill="#c4b5fd" className="text-xs font-orbitron">
                    MOON
                  </text>
                  <text x="100" y="110" textAnchor="middle" fill="#c4b5fd" className="text-xs font-orbitron">
                    Token
                  </text>
                </svg>

                {/* Glow effect */}
                <div className="absolute inset-0 bg-purple-500/5 rounded-full blur-xl -z-10"></div>
              </div>

              {/* Legend */}
              <div className="space-y-3">
                {tokenAllocation.map((item, index) => (
                  <div key={index} className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }}></div>
                    <span className="text-purple-100 font-orbitron text-sm">{item.name}</span>
                    <span className="text-purple-200 font-orbitron text-sm ml-auto">{item.percentage}%</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-purple-400"></div>
                  <span className="text-purple-100 font-orbitron text-sm">Public Sale</span>
                </div>
                <span className="text-purple-200 font-orbitron text-sm">30%</span>
              </div>
              <div className="w-full bg-purple-900/50 rounded-full h-2">
                <div
                  className="bg-gradient-to-r from-purple-400 to-purple-500 h-2 rounded-full"
                  style={{ width: "30%" }}
                ></div>
              </div>

              <div className="flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-purple-500"></div>
                  <span className="text-purple-100 font-orbitron text-sm">Team & Advisors</span>
                </div>
                <span className="text-purple-200 font-orbitron text-sm">20%</span>
              </div>
              <div className="w-full bg-purple-900/50 rounded-full h-2">
                <div
                  className="bg-gradient-to-r from-purple-500 to-purple-600 h-2 rounded-full"
                  style={{ width: "20%" }}
                ></div>
              </div>

              <div className="flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-purple-600"></div>
                  <span className="text-purple-100 font-orbitron text-sm">Ecosystem Development</span>
                </div>
                <span className="text-purple-200 font-orbitron text-sm">25%</span>
              </div>
              <div className="w-full bg-purple-900/50 rounded-full h-2">
                <div
                  className="bg-gradient-to-r from-purple-600 to-purple-700 h-2 rounded-full"
                  style={{ width: "25%" }}
                ></div>
              </div>

              <div className="flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-purple-700"></div>
                  <span className="text-purple-100 font-orbitron text-sm">Treasury</span>
                </div>
                <span className="text-purple-200 font-orbitron text-sm">15%</span>
              </div>
              <div className="w-full bg-purple-900/50 rounded-full h-2">
                <div
                  className="bg-gradient-to-r from-purple-700 to-purple-800 h-2 rounded-full"
                  style={{ width: "15%" }}
                ></div>
              </div>

              <div className="flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-purple-300"></div>
                  <span className="text-purple-100 font-orbitron text-sm">Marketing & Partnerships</span>
                </div>
                <span className="text-purple-200 font-orbitron text-sm">10%</span>
              </div>
              <div className="w-full bg-purple-900/50 rounded-full h-2">
                <div
                  className="bg-gradient-to-r from-purple-300 to-purple-400 h-2 rounded-full"
                  style={{ width: "10%" }}
                ></div>
              </div>
            </div>

            <div className="mt-6 pt-6 border-t border-purple-300/20">
              <div className="flex items-center gap-2 mb-2">
                <CoinsIcon className="h-5 w-5 text-purple-300" />
                <h3 className="text-lg font-semibold font-orbitron text-purple-200">Token Details</h3>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-purple-100/70 font-orbitron text-xs">Token Name</p>
                  <p className="text-purple-200 font-orbitron text-sm">MoonCity</p>
                </div>
                <div>
                  <p className="text-purple-100/70 font-orbitron text-xs">Symbol</p>
                  <p className="text-purple-200 font-orbitron text-sm">MOON</p>
                </div>
                <div>
                  <p className="text-purple-100/70 font-orbitron text-xs">Total Supply</p>
                  <p className="text-purple-200 font-orbitron text-sm">100,000,000 MOON</p>
                </div>
                <div>
                  <p className="text-purple-100/70 font-orbitron text-xs">Blockchain</p>
                  <p className="text-purple-200 font-orbitron text-sm">Solana</p>
                </div>
              </div>
            </div>
          </div>

          {/* Vesting Schedule */}
          <div className="bg-gradient-to-r from-purple-900/30 to-purple-800/30 backdrop-blur-md border border-purple-300/20 rounded-lg p-6 shadow-[0_0_20px_rgba(168,85,247,0.1)]">
            <div className="flex items-center gap-2 mb-6">
              <CalendarIcon className="h-6 w-6 text-purple-300" />
              <h2 className="text-2xl font-bold font-orbitron text-purple-200">Vesting Schedule</h2>
            </div>

            <div className="space-y-6">
              <div className="bg-gradient-to-r from-purple-500/10 to-purple-600/10 backdrop-blur-md border border-purple-300/20 rounded-lg p-4">
                <h3 className="text-lg font-semibold font-orbitron text-purple-200 mb-2">Public Sale</h3>
                <p className="text-purple-100 font-orbitron text-sm mb-2">
                  30% unlocked at TGE, 70% linear vesting over 6 months
                </p>
                <div className="w-full bg-purple-900/50 rounded-full h-2">
                  <div
                    className="bg-gradient-to-r from-purple-400 to-purple-500 h-2 rounded-full"
                    style={{ width: "30%" }}
                  ></div>
                </div>
              </div>

              <div className="bg-gradient-to-r from-purple-500/10 to-purple-600/10 backdrop-blur-md border border-purple-300/20 rounded-lg p-4">
                <h3 className="text-lg font-semibold font-orbitron text-purple-200 mb-2">Team & Advisors</h3>
                <p className="text-purple-100 font-orbitron text-sm mb-2">
                  12 month cliff, then linear vesting over 24 months
                </p>
                <div className="w-full bg-purple-900/50 rounded-full h-2">
                  <div
                    className="bg-gradient-to-r from-purple-500 to-purple-600 h-2 rounded-full"
                    style={{ width: "0%" }}
                  ></div>
                </div>
              </div>

              <div className="bg-gradient-to-r from-purple-500/10 to-purple-600/10 backdrop-blur-md border border-purple-300/20 rounded-lg p-4">
                <h3 className="text-lg font-semibold font-orbitron text-purple-200 mb-2">Ecosystem Development</h3>
                <p className="text-purple-100 font-orbitron text-sm mb-2">
                  10% at TGE, then linear vesting over 36 months
                </p>
                <div className="w-full bg-purple-900/50 rounded-full h-2">
                  <div
                    className="bg-gradient-to-r from-purple-600 to-purple-700 h-2 rounded-full"
                    style={{ width: "10%" }}
                  ></div>
                </div>
              </div>
            </div>

            <div className="mt-6 pt-6 border-t border-purple-300/20">
              <div className="flex items-center gap-2 mb-2">
                <UsersIcon className="h-5 w-5 text-purple-300" />
                <h3 className="text-lg font-semibold font-orbitron text-purple-200">Token Utility</h3>
              </div>
              <ul className="space-y-2">
                <li className="flex items-start gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-purple-400 mt-1.5"></div>
                  <p className="text-purple-100 font-orbitron text-sm">Access to premium sniping agents and features</p>
                </li>
                <li className="flex items-start gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-purple-400 mt-1.5"></div>
                  <p className="text-purple-100 font-orbitron text-sm">
                    Community voting rights for platform development
                  </p>
                </li>
                <li className="flex items-start gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-purple-400 mt-1.5"></div>
                  <p className="text-purple-100 font-orbitron text-sm">Fee discounts for platform services</p>
                </li>
                <li className="flex items-start gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-purple-400 mt-1.5"></div>
                  <p className="text-purple-100 font-orbitron text-sm">Staking rewards and revenue sharing</p>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <Footer />
    </div>
  )
}
