"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  MoonIcon,
  Link2Icon,
  BarChart3Icon,
  ZapIcon,
  TrendingUpIcon,
  RefreshCwIcon,
  ClockIcon,
  FlameIcon,
  StarIcon,
} from "lucide-react"
import StarField from "@/components/star-field"
import Link from "next/link"
import Footer from "@/components/footer"

interface TrendingTheme {
  id: string
  name: string
  description: string
  rating: number
  volume24h: string
  tokens: number
  growth: string
  emoji: string
  color: string
  overview: string
  topTokens: string[]
  marketCap: string
  avgScore: number
  lastUpdated: string
  trendingHashtags: string[]
  sentiment: "bullish" | "bearish" | "neutral"
  influencerMentions: number
  communitySize: number
  weeklyGrowth: string
  monthlyGrowth: string
  riskLevel: "Low" | "Medium" | "High"
  category: string
}

// Refined crypto themes without images for cleaner design
const createTrendingThemes = (): TrendingTheme[] => {
  const baseThemes = [
    {
      id: "1",
      name: "AI Agent Tokens",
      description:
        "Autonomous AI-powered trading agents revolutionizing DeFi with smart contract automation and predictive analytics",
      rating: 9.6,
      volume24h: "$12.4M",
      tokens: 89,
      growth: "+234%",
      emoji: "🤖",
      color: "from-blue-500 to-cyan-500",
      overview:
        "AI agent tokens represent the cutting edge of decentralized finance, combining artificial intelligence with blockchain technology to create autonomous trading systems. These tokens power sophisticated algorithms that can analyze market conditions, execute trades, and optimize portfolio performance without human intervention. The sector has seen explosive growth as institutional investors recognize the potential for AI-driven strategies to outperform traditional trading methods.",
      topTokens: ["AIAGENT", "BOTCOIN", "NEURAL", "AUTOAI"],
      marketCap: "$187.3M",
      avgScore: 94,
      trendingHashtags: ["#AIAgents", "#AutoTrading", "#AITokens", "#BotTrading"],
      sentiment: "bullish" as const,
      influencerMentions: 47,
      communitySize: 15420,
      weeklyGrowth: "+89%",
      monthlyGrowth: "+312%",
      riskLevel: "Medium" as const,
      category: "Technology",
    },
    {
      id: "2",
      name: "Meme Coin Revolution",
      description:
        "Community-driven meme tokens creating viral movements and establishing new paradigms in decentralized culture",
      rating: 9.2,
      volume24h: "$8.7M",
      tokens: 156,
      growth: "+189%",
      emoji: "🐸",
      color: "from-green-500 to-emerald-500",
      overview:
        "The meme coin revolution has evolved beyond simple internet jokes to become a legitimate force in cryptocurrency markets. These community-driven tokens leverage viral marketing, social media engagement, and collective enthusiasm to build substantial ecosystems. Modern meme coins often incorporate utility features, governance mechanisms, and charitable initiatives, proving that humor and finance can coexist profitably while fostering genuine community bonds.",
      topTokens: ["PEPE2", "WOJAK", "GIGACHAD", "BASED"],
      marketCap: "$234.8M",
      avgScore: 89,
      trendingHashtags: ["#MemeCoin", "#Community", "#Viral", "#Culture"],
      sentiment: "bullish" as const,
      influencerMentions: 73,
      communitySize: 28750,
      weeklyGrowth: "+156%",
      monthlyGrowth: "+445%",
      riskLevel: "High" as const,
      category: "Community",
    },
    {
      id: "3",
      name: "Real World Assets",
      description:
        "Tokenization of physical assets bringing traditional finance onto blockchain with institutional backing",
      rating: 9.4,
      volume24h: "$15.2M",
      tokens: 34,
      growth: "+156%",
      emoji: "🏢",
      color: "from-purple-500 to-violet-500",
      overview:
        "Real World Asset (RWA) tokenization represents a paradigm shift in how we interact with traditional investments. By converting physical assets like real estate, commodities, and securities into blockchain tokens, this sector bridges the gap between traditional finance and DeFi. Institutional adoption is accelerating as major financial institutions recognize the benefits of increased liquidity, fractional ownership, and 24/7 trading capabilities.",
      topTokens: ["REALTY", "GOLD", "CARBON", "ESTATE"],
      marketCap: "$456.7M",
      avgScore: 96,
      trendingHashtags: ["#RWA", "#Tokenization", "#Institutional", "#Assets"],
      sentiment: "bullish" as const,
      influencerMentions: 28,
      communitySize: 8940,
      weeklyGrowth: "+67%",
      monthlyGrowth: "+234%",
      riskLevel: "Low" as const,
      category: "Finance",
    },
    {
      id: "4",
      name: "Gaming Metaverse",
      description: "Play-to-earn gaming ecosystems with immersive virtual worlds and blockchain-based asset ownership",
      rating: 8.8,
      volume24h: "$6.3M",
      tokens: 67,
      growth: "+123%",
      emoji: "🎮",
      color: "from-red-500 to-orange-500",
      overview:
        "The gaming metaverse sector is transforming how players interact with virtual worlds by introducing true asset ownership and play-to-earn mechanics. These platforms combine immersive gaming experiences with blockchain technology, allowing players to own, trade, and monetize in-game assets. Major game studios are partnering with blockchain projects to create sustainable gaming economies that reward player engagement and skill.",
      topTokens: ["EPICGAME", "UNITY", "P2E", "METAVERSE"],
      marketCap: "$89.4M",
      avgScore: 87,
      trendingHashtags: ["#GameFi", "#P2E", "#Metaverse", "#Gaming"],
      sentiment: "bullish" as const,
      influencerMentions: 34,
      communitySize: 19650,
      weeklyGrowth: "+78%",
      monthlyGrowth: "+198%",
      riskLevel: "Medium" as const,
      category: "Entertainment",
    },
    {
      id: "5",
      name: "Solana Ecosystem",
      description:
        "High-performance blockchain ecosystem with lightning-fast transactions and innovative DeFi protocols",
      rating: 9.1,
      volume24h: "$11.8M",
      tokens: 78,
      growth: "+167%",
      emoji: "☀️",
      color: "from-purple-600 to-pink-500",
      overview:
        "The Solana ecosystem continues to demonstrate the power of high-throughput blockchain technology with its sub-second transaction times and minimal fees. Recent developments include major DEX launches, innovative DeFi protocols, and significant airdrop announcements that have energized the community. The ecosystem's focus on user experience and developer tools has attracted both retail and institutional adoption.",
      topTokens: ["JUP", "ORCA", "RAY", "BONK"],
      marketCap: "$678.9M",
      avgScore: 92,
      trendingHashtags: ["#Solana", "#HighSpeed", "#DeFi", "#Ecosystem"],
      sentiment: "bullish" as const,
      influencerMentions: 56,
      communitySize: 34200,
      weeklyGrowth: "+134%",
      monthlyGrowth: "+289%",
      riskLevel: "Low" as const,
      category: "Infrastructure",
    },
    {
      id: "6",
      name: "Layer 2 Scaling",
      description:
        "Advanced scaling solutions reducing transaction costs while maintaining security and decentralization",
      rating: 8.9,
      volume24h: "$9.1M",
      tokens: 45,
      growth: "+134%",
      emoji: "⚡",
      color: "from-blue-600 to-indigo-500",
      overview:
        "Layer 2 scaling solutions are addressing Ethereum's scalability challenges through innovative rollup technology and sidechains. These solutions maintain the security guarantees of the main chain while dramatically reducing transaction costs and increasing throughput. Major DeFi protocols are migrating to L2 solutions, creating a more accessible and efficient ecosystem for users worldwide.",
      topTokens: ["ARB", "OP", "MATIC", "LRC"],
      marketCap: "$345.6M",
      avgScore: 90,
      trendingHashtags: ["#Layer2", "#Scaling", "#Ethereum", "#Efficiency"],
      sentiment: "bullish" as const,
      influencerMentions: 41,
      communitySize: 22100,
      weeklyGrowth: "+89%",
      monthlyGrowth: "+201%",
      riskLevel: "Low" as const,
      category: "Infrastructure",
    },
  ]

  // Add dynamic data to simulate real-time updates
  return baseThemes.map((theme) => ({
    ...theme,
    lastUpdated: `${Math.floor(Math.random() * 5) + 1}m ago`,
  }))
}

export default function TrendingThemesPage() {
  const [themes, setThemes] = useState<TrendingTheme[]>([])
  const [lastRefresh, setLastRefresh] = useState<Date>(new Date())
  const [isRefreshing, setIsRefreshing] = useState(false)

  // Initialize themes and set up real-time updates
  useEffect(() => {
    const updateThemes = () => {
      setThemes(createTrendingThemes())
      setLastRefresh(new Date())
    }

    updateThemes()

    // Update themes every 30 seconds to simulate real-time data
    const interval = setInterval(updateThemes, 30000)

    return () => clearInterval(interval)
  }, [])

  const handleRefresh = async () => {
    setIsRefreshing(true)

    // Simulate API call delay
    await new Promise((resolve) => setTimeout(resolve, 1000))

    setThemes(createTrendingThemes())
    setLastRefresh(new Date())
    setIsRefreshing(false)
  }

  const getRatingColor = (rating: number) => {
    if (rating >= 9.0) return "text-green-400"
    if (rating >= 8.5) return "text-yellow-400"
    if (rating >= 8.0) return "text-orange-400"
    return "text-red-400"
  }

  const getGrowthColor = (growth: string) => {
    const value = Number.parseInt(growth.replace("+", "").replace("%", ""))
    if (value >= 150) return "text-green-400"
    if (value >= 100) return "text-yellow-400"
    return "text-orange-400"
  }

  const getSentimentColor = (sentiment: string) => {
    switch (sentiment) {
      case "bullish":
        return "text-green-400"
      case "bearish":
        return "text-red-400"
      default:
        return "text-yellow-400"
    }
  }

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case "Low":
        return "text-green-400 bg-green-500/10 border-green-400/30"
      case "Medium":
        return "text-yellow-400 bg-yellow-500/10 border-yellow-400/30"
      case "High":
        return "text-red-400 bg-red-500/10 border-red-400/30"
      default:
        return "text-purple-400 bg-purple-500/10 border-purple-400/30"
    }
  }

  // Format large numbers with K/M suffixes
  const formatNumber = (num: number): string => {
    if (num >= 1000000) {
      return `${(num / 1000000).toFixed(1)}M`
    }
    if (num >= 1000) {
      return `${(num / 1000).toFixed(1)}K`
    }
    return num.toString()
  }

  return (
    <div className="relative min-h-screen overflow-hidden bg-gradient-to-br from-[#0a0520] to-[#1a0f3a]">
      {/* Star background */}
      <StarField />

      {/* Moon graphic with subtle glow */}
      <div className="absolute top-8 right-8 w-[150px] h-[150px] rounded-full bg-gradient-to-br from-purple-300/30 to-purple-400/20 shadow-[0_0_40px_rgba(196,169,255,0.4)] blur-sm hidden md:block" />
      <div className="absolute top-10 right-10 w-[110px] h-[110px] rounded-full bg-gradient-to-br from-purple-200/40 to-purple-300/30 shadow-[0_0_25px_rgba(216,180,254,0.5)] hidden md:block" />

      <div className="container mx-auto px-4">
        {/* Navigation with subtle effects */}
        <header className="flex items-center justify-between py-6">
          <div className="flex items-center gap-2">
            <Link href="/" className="flex items-center gap-2">
              <MoonIcon className="h-6 w-6 text-purple-300 drop-shadow-[0_0_5px_rgba(196,169,255,0.6)]" />
              <span className="text-xl font-bold font-orbitron text-purple-300 drop-shadow-[0_0_5px_rgba(196,169,255,0.6)]">
                MoonCity AI
              </span>
            </Link>
          </div>

          <nav className="hidden md:flex items-center gap-6">
            <Link href="/">
              <Button
                variant="link"
                className="text-purple-100 hover:text-purple-200 font-orbitron border border-transparent hover:border-purple-300/30 hover:shadow-[0_0_10px_rgba(196,169,255,0.2)] transition-all duration-300"
              >
                🏠 Home
              </Button>
            </Link>
            <Link href="/live-coins">
              <Button
                variant="link"
                className="text-purple-100 hover:text-purple-200 font-orbitron border border-transparent hover:border-purple-300/30 hover:shadow-[0_0_10px_rgba(196,169,255,0.2)] transition-all duration-300"
              >
                🪙 Live Coins
              </Button>
            </Link>
            <Link href="/trending-themes">
              <Button
                variant="link"
                className="text-purple-100 hover:text-purple-200 font-orbitron border border-transparent hover:border-purple-300/30 hover:shadow-[0_0_10px_rgba(196,169,255,0.2)] transition-all duration-300"
              >
                🔥 Trending Themes
              </Button>
            </Link>
            <Link href="/whitepaper">
              <Button
                variant="link"
                className="text-purple-100 hover:text-purple-200 font-orbitron border border-transparent hover:border-purple-300/30 hover:shadow-[0_0_10px_rgba(196,169,255,0.2)] transition-all duration-300"
              >
                📝 Whitepaper
              </Button>
            </Link>
            <Link href="/token-distribution">
              <Button
                variant="link"
                className="text-purple-100 hover:text-purple-200 font-orbitron border border-transparent hover:border-purple-300/30 hover:shadow-[0_0_10px_rgba(196,169,255,0.2)] transition-all duration-300"
              >
                💰 Token Distribution
              </Button>
            </Link>
          </nav>

          <div className="flex items-center gap-3">
            <a href="https://t.me/mooncitylink" target="_blank" rel="noopener noreferrer">
              <Button className="bg-gradient-to-r from-sky-400 to-sky-500 hover:from-sky-500 hover:to-sky-600 text-white border border-sky-300/50 shadow-[0_0_15px_rgba(56,189,248,0.3)] hover:shadow-[0_0_20px_rgba(56,189,248,0.4)] transition-all duration-300 font-orbitron">
                <Link2Icon className="mr-2 h-4 w-4" />📱 Telegram
              </Button>
            </a>
            <a href="https://x.com/MoonCityAI" target="_blank" rel="noopener noreferrer">
              <Button className="bg-gradient-to-r from-sky-500 to-sky-600 hover:from-sky-600 hover:to-sky-700 text-white border border-sky-300/50 shadow-[0_0_15px_rgba(14,165,233,0.3)] hover:shadow-[0_0_20px_rgba(14,165,233,0.4)] transition-all duration-300 font-orbitron">
                <svg className="mr-2 h-4 w-4" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
                </svg>
                🐦 Twitter
              </Button>
            </a>
          </div>
        </header>

        {/* Page Header */}
        <div className="py-12 text-center">
          <h1 className="text-4xl md:text-6xl font-bold font-orbitron bg-gradient-to-r from-purple-200 via-purple-300 to-purple-400 bg-clip-text text-transparent leading-tight max-w-4xl mx-auto drop-shadow-[0_0_15px_rgba(196,169,255,0.4)]">
            <span className="mr-2">🔥</span> Trending Crypto Themes
          </h1>
          <p className="mt-4 text-purple-100 max-w-2xl mx-auto font-orbitron text-lg drop-shadow-[0_0_5px_rgba(216,180,254,0.3)]">
            Discover the hottest cryptocurrency themes and emerging market trends with real-time analytics
          </p>

          {/* Prominent PumpFun Theme Button */}
          <div className="flex justify-center mt-8 mb-6">
            <Link href="/live-coins">
              <Button className="bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 text-white px-8 py-6 text-xl border border-orange-300/50 shadow-[0_0_20px_rgba(245,158,11,0.4)] hover:shadow-[0_0_25px_rgba(245,158,11,0.5)] transition-all duration-300 font-orbitron font-bold">
                <FlameIcon className="mr-3 h-6 w-6" />🚀 Explore PumpFun Themes
              </Button>
            </Link>
          </div>

          {/* Control Panel */}
          <div className="mt-8 flex flex-wrap items-center justify-center gap-4">
            <div className="bg-gradient-to-r from-purple-500/20 to-purple-600/20 backdrop-blur-md border border-purple-300/30 rounded-full px-4 py-2 flex items-center gap-2">
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
              <span className="text-purple-200 font-orbitron text-sm">📊 Live Market Data</span>
            </div>

            <Button
              onClick={handleRefresh}
              disabled={isRefreshing}
              className="bg-gradient-to-r from-purple-500/20 to-purple-600/20 backdrop-blur-md border border-purple-300/30 text-purple-200 hover:bg-purple-500/30 font-orbitron px-6 py-2"
            >
              <RefreshCwIcon className={`h-4 w-4 mr-2 ${isRefreshing ? "animate-spin" : ""}`} />🔄 Refresh Data
            </Button>

            <div className="flex items-center gap-2 text-purple-300/60 font-orbitron text-sm">
              <ClockIcon className="h-4 w-4" />
              <span>⏰ Updated {lastRefresh.toLocaleTimeString()}</span>
            </div>
          </div>
        </div>

        {/* Market Overview Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12">
          <div className="bg-gradient-to-r from-purple-550/20 to-purple-650/20 backdrop-blur-md border border-purple-350/30 rounded-lg p-6 shadow-[0_0_15px_rgba(168,85,247,0.1)]">
            <div className="flex items-center gap-3 mb-3">
              <TrendingUpIcon className="h-6 w-6 text-green-400" />
              <span className="text-purple-200 font-orbitron text-sm font-semibold">📈 Total Volume</span>
            </div>
            <div className="text-3xl font-bold font-orbitron text-purple-100">$63.5M</div>
            <div className="text-sm text-green-400 font-orbitron">+89.3% today</div>
          </div>

          <div className="bg-gradient-to-r from-purple-550/20 to-purple-650/20 backdrop-blur-md border border-purple-350/30 rounded-lg p-6 shadow-[0_0_15px_rgba(168,85,247,0.1)]">
            <div className="flex items-center gap-3 mb-3">
              <BarChart3Icon className="h-6 w-6 text-blue-400" />
              <span className="text-purple-200 font-orbitron text-sm font-semibold">🔥 Active Themes</span>
            </div>
            <div className="text-3xl font-bold font-orbitron text-purple-100">{themes.length}</div>
            <div className="text-sm text-yellow-400 font-orbitron">+3 new today</div>
          </div>

          <div className="bg-gradient-to-r from-purple-550/20 to-purple-650/20 backdrop-blur-md border border-purple-350/30 rounded-lg p-6 shadow-[0_0_15px_rgba(168,85,247,0.1)]">
            <div className="flex items-center gap-3 mb-3">
              <StarIcon className="h-6 w-6 text-yellow-400" />
              <span className="text-purple-200 font-orbitron text-sm font-semibold">⭐ Avg Rating</span>
            </div>
            <div className="text-3xl font-bold font-orbitron text-purple-100">9.0</div>
            <div className="text-sm text-green-400 font-orbitron">Excellent</div>
          </div>

          <div className="bg-gradient-to-r from-purple-550/20 to-purple-650/20 backdrop-blur-md border border-purple-350/30 rounded-lg p-6 shadow-[0_0_15px_rgba(168,85,247,0.1)]">
            <div className="flex items-center gap-3 mb-3">
              <ZapIcon className="h-6 w-6 text-purple-400" />
              <span className="text-purple-200 font-orbitron text-sm font-semibold">📊 Market Sentiment</span>
            </div>
            <div className="text-3xl font-bold font-orbitron text-green-400">Bullish</div>
            <div className="text-sm text-green-400 font-orbitron">92% positive</div>
          </div>
        </div>

        {/* Trending Themes Grid - Removed Images for Cleaner Design */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-16">
          {themes.map((theme) => (
            <div
              key={theme.id}
              className="bg-gradient-to-br from-purple-850/30 to-purple-750/30 backdrop-blur-md border border-purple-350/20 rounded-xl overflow-hidden shadow-[0_0_20px_rgba(168,85,247,0.1)] hover:shadow-[0_0_25px_rgba(168,85,247,0.2)] transition-all duration-300 hover:scale-[1.01]"
            >
              {/* Theme Header */}
              <div className="p-8 border-b border-purple-350/20">
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center gap-6">
                    <div className="w-16 h-16 rounded-full bg-gradient-to-br from-purple-400 to-purple-600 flex items-center justify-center text-white text-3xl font-bold shadow-lg">
                      {theme.emoji}
                    </div>
                    <div>
                      <h3 className="text-2xl font-bold font-orbitron text-white mb-2">{theme.name}</h3>
                      <div className="flex items-center gap-3">
                        <Badge variant="outline" className={`text-sm font-orbitron ${getRiskColor(theme.riskLevel)}`}>
                          🛡️ {theme.riskLevel} Risk
                        </Badge>
                        <Badge
                          variant="outline"
                          className="text-sm font-orbitron bg-purple-500/10 border-purple-300/30 text-purple-200"
                        >
                          📂 {theme.category}
                        </Badge>
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className={`text-3xl font-bold font-orbitron ${getRatingColor(theme.rating)}`}>
                      {theme.rating}
                    </div>
                    <div className="text-sm text-purple-300 font-orbitron">Rating</div>
                  </div>
                </div>

                <p className="text-purple-100 font-orbitron text-base leading-relaxed">{theme.description}</p>
              </div>

              {/* Detailed Overview */}
              <div className="p-8">
                <h4 className="text-xl font-semibold font-orbitron text-purple-200 mb-4">📋 Market Overview</h4>
                <p className="text-purple-100/80 font-orbitron text-sm leading-relaxed mb-8">{theme.overview}</p>

                {/* Key Metrics Grid */}
                <div className="grid grid-cols-2 gap-6 mb-8">
                  <div className="bg-purple-500/10 rounded-lg p-5 border border-purple-300/20">
                    <div className="text-purple-200 font-orbitron text-sm mb-2">💰 Market Cap</div>
                    <div className="text-purple-100 font-orbitron font-bold text-xl">{theme.marketCap}</div>
                    <div className={`text-sm font-orbitron ${getGrowthColor(theme.growth)}`}>📈 {theme.growth}</div>
                  </div>
                  <div className="bg-purple-500/10 rounded-lg p-5 border border-purple-300/20">
                    <div className="text-purple-200 font-orbitron text-sm mb-2">📊 24h Volume</div>
                    <div className="text-purple-100 font-orbitron font-bold text-xl">{theme.volume24h}</div>
                    <div className="text-sm text-green-400 font-orbitron">🔥 {theme.tokens} tokens</div>
                  </div>
                  <div className="bg-purple-500/10 rounded-lg p-5 border border-purple-300/20">
                    <div className="text-purple-200 font-orbitron text-sm mb-2">👥 Community</div>
                    <div className="text-purple-100 font-orbitron font-bold text-xl">
                      {formatNumber(theme.communitySize)}
                    </div>
                    <div className="text-sm text-blue-400 font-orbitron">📈 {theme.weeklyGrowth} weekly</div>
                  </div>
                  <div className="bg-purple-500/10 rounded-lg p-5 border border-purple-300/20">
                    <div className="text-purple-200 font-orbitron text-sm mb-2">📈 Monthly Growth</div>
                    <div className="text-green-400 font-orbitron font-bold text-xl">{theme.monthlyGrowth}</div>
                    <div className="text-sm text-purple-300 font-orbitron">⏰ {theme.lastUpdated}</div>
                  </div>
                </div>

                {/* Trending Hashtags */}
                <div className="mb-8">
                  <h5 className="text-lg font-semibold font-orbitron text-purple-200 mb-4">🏷️ Trending Tags</h5>
                  <div className="flex flex-wrap gap-3">
                    {theme.trendingHashtags.map((hashtag) => (
                      <Badge
                        key={hashtag}
                        variant="outline"
                        className="text-sm font-orbitron bg-sky-500/10 border-sky-300/30 text-sky-200 hover:bg-sky-500/20 transition-colors"
                      >
                        {hashtag}
                      </Badge>
                    ))}
                  </div>
                </div>

                {/* Top Tokens */}
                <div className="mb-8">
                  <h5 className="text-lg font-semibold font-orbitron text-purple-200 mb-4">🪙 Top Tokens</h5>
                  <div className="flex flex-wrap gap-3">
                    {theme.topTokens.map((token) => (
                      <Badge
                        key={token}
                        variant="outline"
                        className="text-sm font-orbitron bg-purple-500/10 border-purple-300/30 text-purple-200 hover:bg-purple-500/20 transition-colors"
                      >
                        ${token}
                      </Badge>
                    ))}
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex gap-4">
                  <Button className="flex-1 bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700 text-white border border-purple-400/50 shadow-[0_0_15px_rgba(168,85,247,0.3)] hover:shadow-[0_0_20px_rgba(168,85,247,0.4)] transition-all duration-300 font-orbitron py-4">
                    <BarChart3Icon className="mr-2 h-5 w-5" />📊 View Analytics
                  </Button>
                  <Link href="/live-coins" className="flex-1">
                    <Button className="w-full bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white border border-green-400/50 shadow-[0_0_15px_rgba(34,197,94,0.3)] hover:shadow-[0_0_20px_rgba(34,197,94,0.4)] transition-all duration-300 font-orbitron py-4">
                      <TrendingUpIcon className="mr-2 h-5 w-5" />🚀 Explore Tokens
                    </Button>
                  </Link>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Footer */}
      <Footer />
    </div>
  )
}
