import { Button } from "@/components/ui/button"
import {
  MoonIcon,
  Link2Icon,
  FileTextIcon,
  DownloadIcon,
  RocketIcon,
  EyeIcon,
  ZapIcon,
  LayoutIcon,
  CoinsIcon,
  MapIcon,
  UsersIcon,
  CheckCircleIcon,
  BrainIcon,
  LineChartIcon,
  ShieldIcon,
  GlobeIcon,
  HeartIcon,
} from "lucide-react"
import StarField from "@/components/star-field"
import Link from "next/link"
import Footer from "@/components/footer"

export default function WhitepaperPage() {
  return (
    <div className="relative min-h-screen overflow-hidden bg-gradient-to-br from-[#0a0520] to-[#1a0f3a]">
      {/* Star background */}
      <StarField />

      {/* Moon graphic with subtle glow */}
      <div className="absolute top-8 right-8 w-[150px] h-[150px] rounded-full bg-gradient-to-br from-purple-300/30 to-purple-400/20 shadow-[0_0_40px_rgba(196,169,255,0.4)] blur-sm hidden md:block" />
      <div className="absolute top-10 right-10 w-[110px] h-[110px] rounded-full bg-gradient-to-br from-purple-200/40 to-purple-300/30 shadow-[0_0_25px_rgba(216,180,254,0.5)] hidden md:block" />

      <div className="container mx-auto px-4">
        {/* Navigation with subtle effects */}
        <header className="flex items-center justify-between py-6">
          <div className="flex items-center gap-2">
            <Link href="/" className="flex items-center gap-2">
              <MoonIcon className="h-6 w-6 text-purple-300 drop-shadow-[0_0_5px_rgba(196,169,255,0.6)]" />
              <span className="text-xl font-bold font-orbitron text-purple-300 drop-shadow-[0_0_5px_rgba(196,169,255,0.6)]">
                MoonCity AI
              </span>
            </Link>
          </div>

          <nav className="hidden md:flex items-center gap-6">
            <Link href="/">
              <Button
                variant="link"
                className="text-purple-100 hover:text-purple-200 font-orbitron border border-transparent hover:border-purple-300/30 hover:shadow-[0_0_10px_rgba(196,169,255,0.2)] transition-all duration-300"
              >
                Home
              </Button>
            </Link>
            <Link href="/live-coins">
              <Button
                variant="link"
                className="text-purple-100 hover:text-purple-200 font-orbitron border border-transparent hover:border-purple-300/30 hover:shadow-[0_0_10px_rgba(196,169,255,0.2)] transition-all duration-300"
              >
                Live Coins
              </Button>
            </Link>
            <Link href="/whitepaper">
              <Button
                variant="link"
                className="text-purple-100 hover:text-purple-200 font-orbitron border border-transparent hover:border-purple-300/30 hover:shadow-[0_0_10px_rgba(196,169,255,0.2)] transition-all duration-300"
              >
                Whitepaper
              </Button>
            </Link>
            <Link href="/token-distribution">
              <Button
                variant="link"
                className="text-purple-100 hover:text-purple-200 font-orbitron border border-transparent hover:border-purple-300/30 hover:shadow-[0_0_10px_rgba(196,169,255,0.2)] transition-all duration-300"
              >
                Token Distribution
              </Button>
            </Link>
          </nav>

          <div className="flex items-center gap-2">
            <a href="https://t.me/mooncitylink" target="_blank" rel="noopener noreferrer">
              <Button className="bg-gradient-to-r from-sky-400 to-sky-500 hover:from-sky-500 hover:to-sky-600 text-white border border-sky-300/50 shadow-[0_0_15px_rgba(56,189,248,0.3)] hover:shadow-[0_0_20px_rgba(56,189,248,0.4)] transition-all duration-300 font-orbitron">
                <Link2Icon className="mr-2 h-4 w-4" />
                Telegram
              </Button>
            </a>
            <a href="https://x.com/MoonCityAI" target="_blank" rel="noopener noreferrer">
              <Button className="bg-gradient-to-r from-sky-500 to-sky-600 hover:from-sky-600 hover:to-sky-700 text-white border border-sky-300/50 shadow-[0_0_15px_rgba(14,165,233,0.3)] hover:shadow-[0_0_20px_rgba(14,165,233,0.4)] transition-all duration-300 font-orbitron">
                <svg className="mr-2 h-4 w-4" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
                </svg>
                Twitter
              </Button>
            </a>
          </div>
        </header>

        {/* Whitepaper Header */}
        <div className="py-12 text-center">
          <h1 className="text-4xl md:text-6xl font-bold font-orbitron bg-gradient-to-r from-purple-200 via-purple-300 to-purple-400 bg-clip-text text-transparent leading-tight max-w-4xl mx-auto drop-shadow-[0_0_15px_rgba(196,169,255,0.4)]">
            MoonCity AI Whitepaper 📝
          </h1>
          <p className="mt-4 text-purple-100 max-w-2xl mx-auto font-orbitron text-lg drop-shadow-[0_0_5px_rgba(216,180,254,0.3)]">
            Our vision, technology, and roadmap for revolutionizing Solana token sniping
          </p>
          <div className="mt-6">
            <Button className="bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700 text-white px-6 py-3 border border-purple-400/50 shadow-[0_0_20px_rgba(168,85,247,0.4)] hover:shadow-[0_0_25px_rgba(168,85,247,0.5)] transition-all duration-300 font-orbitron">
              <DownloadIcon className="mr-2 h-4 w-4" />
              Download PDF
            </Button>
          </div>
        </div>

        {/* Whitepaper Content */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 py-8">
          {/* Table of Contents */}
          <div className="md:col-span-1">
            <div className="bg-gradient-to-r from-purple-850/30 to-purple-750/30 backdrop-blur-md border border-purple-350/20 rounded-lg p-6 shadow-[0_0_20px_rgba(168,85,247,0.1)] sticky top-6">
              <div className="flex items-center gap-2 mb-4">
                <FileTextIcon className="h-5 w-5 text-purple-300" />
                <h3 className="text-xl font-bold font-orbitron text-purple-200">Table of Contents</h3>
              </div>
              <ul className="space-y-3">
                <li>
                  <a
                    href="#introduction"
                    className="flex items-center gap-2 text-purple-100 hover:text-purple-300 transition-colors"
                  >
                    <RocketIcon className="h-4 w-4 text-purple-400" />
                    <span className="font-orbitron text-sm">Introduction 🚀</span>
                  </a>
                </li>
                <li>
                  <a
                    href="#vision"
                    className="flex items-center gap-2 text-purple-100 hover:text-purple-300 transition-colors"
                  >
                    <EyeIcon className="h-4 w-4 text-purple-400" />
                    <span className="font-orbitron text-sm">Vision & Mission 👁️</span>
                  </a>
                </li>
                <li>
                  <a
                    href="#technology"
                    className="flex items-center gap-2 text-purple-100 hover:text-purple-300 transition-colors"
                  >
                    <ZapIcon className="h-4 w-4 text-purple-400" />
                    <span className="font-orbitron text-sm">Technology ⚡</span>
                  </a>
                </li>
                <li>
                  <a
                    href="#architecture"
                    className="flex items-center gap-2 text-purple-100 hover:text-purple-300 transition-colors"
                  >
                    <LayoutIcon className="h-4 w-4 text-purple-400" />
                    <span className="font-orbitron text-sm">Architecture 🏗️</span>
                  </a>
                </li>
                <li>
                  <a
                    href="#tokenomics"
                    className="flex items-center gap-2 text-purple-100 hover:text-purple-300 transition-colors"
                  >
                    <CoinsIcon className="h-4 w-4 text-purple-400" />
                    <span className="font-orbitron text-sm">Tokenomics 💰</span>
                  </a>
                </li>
                <li>
                  <a
                    href="#roadmap"
                    className="flex items-center gap-2 text-purple-100 hover:text-purple-300 transition-colors"
                  >
                    <MapIcon className="h-4 w-4 text-purple-400" />
                    <span className="font-orbitron text-sm">Roadmap 🗺️</span>
                  </a>
                </li>
                <li>
                  <a
                    href="#team"
                    className="flex items-center gap-2 text-purple-100 hover:text-purple-300 transition-colors"
                  >
                    <UsersIcon className="h-4 w-4 text-purple-400" />
                    <span className="font-orbitron text-sm">Team 👥</span>
                  </a>
                </li>
                <li>
                  <a
                    href="#conclusion"
                    className="flex items-center gap-2 text-purple-100 hover:text-purple-300 transition-colors"
                  >
                    <CheckCircleIcon className="h-4 w-4 text-purple-400" />
                    <span className="font-orbitron text-sm">Conclusion ✅</span>
                  </a>
                </li>
              </ul>
            </div>
          </div>

          {/* Content Sections */}
          <div className="md:col-span-3 space-y-8">
            {/* Introduction */}
            <section
              id="introduction"
              className="bg-gradient-to-r from-purple-800/30 to-purple-700/30 backdrop-blur-md border border-purple-400/20 rounded-lg p-6 shadow-[0_0_20px_rgba(168,85,247,0.1)]"
            >
              <div className="flex items-center gap-2 mb-4">
                <RocketIcon className="h-6 w-6 text-purple-300" />
                <h2 className="text-2xl font-bold font-orbitron text-purple-200">Introduction 🚀</h2>
              </div>
              <div className="space-y-4 text-purple-100">
                <p className="font-orbitron text-sm leading-relaxed">
                  MoonCity AI is changing how people find and invest in new cryptocurrency tokens on the Solana
                  blockchain. This document explains our vision, technology, and plans for building the best token
                  discovery platform.
                </p>
                <p className="font-orbitron text-sm leading-relaxed">
                  In the fast-moving world of crypto, finding good new tokens requires speed and smart analysis. Trying
                  to watch the market manually is nearly impossible with so many new tokens launching every day.
                </p>
                <p className="font-orbitron text-sm leading-relaxed">
                  MoonCity AI solves this by using artificial intelligence to watch the market 24/7, analyze new tokens,
                  and alert you to the most promising opportunities before they become popular.
                </p>
                <div className="bg-purple-550/10 border border-purple-350/20 rounded-lg p-4 mt-4">
                  <h4 className="text-purple-200 font-orbitron font-semibold mb-2 flex items-center gap-2">
                    <span className="text-lg">💡</span> Problems We Solve
                  </h4>
                  <ul className="list-disc pl-6 space-y-2">
                    <li className="font-orbitron text-sm leading-relaxed">
                      <span className="text-purple-300 font-semibold">Too Slow:</span> Humans can't react fast enough to
                      catch new token launches
                    </li>
                    <li className="font-orbitron text-sm leading-relaxed">
                      <span className="text-purple-300 font-semibold">Too Much Data:</span> There's too much information
                      to analyze manually
                    </li>
                    <li className="font-orbitron text-sm leading-relaxed">
                      <span className="text-purple-300 font-semibold">Complex Analysis:</span> Evaluating tokens
                      requires looking at many different factors
                    </li>
                    <li className="font-orbitron text-sm leading-relaxed">
                      <span className="text-purple-300 font-semibold">Timing is Everything:</span> You need to act at
                      exactly the right moment
                    </li>
                  </ul>
                </div>
              </div>
            </section>

            {/* Vision & Mission */}
            <section
              id="vision"
              className="bg-gradient-to-r from-purple-800/30 to-purple-700/30 backdrop-blur-md border border-purple-400/20 rounded-lg p-6 shadow-[0_0_20px_rgba(168,85,247,0.1)]"
            >
              <div className="flex items-center gap-2 mb-4">
                <EyeIcon className="h-6 w-6 text-purple-300" />
                <h2 className="text-2xl font-bold font-orbitron text-purple-200">Vision & Mission 👁️</h2>
              </div>
              <div className="mb-6">
                <h3 className="text-xl font-semibold font-orbitron text-purple-300 flex items-center gap-2 mb-2">
                  <span className="w-2 h-2 rounded-full bg-purple-400"></span>
                  Vision 🔮
                </h3>
                <p className="font-orbitron text-sm leading-relaxed text-purple-100">
                  To make advanced crypto trading tools available to everyone, not just big institutions. We want to
                  give regular people the same powerful technology that professional traders use.
                </p>
                <div className="mt-4 bg-gradient-to-r from-purple-500/10 to-purple-600/10 p-4 rounded-lg border border-purple-300/20">
                  <p className="font-orbitron text-sm italic text-purple-200">
                    "We envision a future where AI-powered trading agents level the playing field, giving individual
                    traders the same technological advantages previously reserved for institutional players."
                  </p>
                </div>
              </div>
              <div>
                <h3 className="text-xl font-semibold font-orbitron text-purple-300 flex items-center gap-2 mb-2">
                  <span className="w-2 h-2 rounded-full bg-purple-400"></span>
                  Mission 🎯
                </h3>
                <p className="font-orbitron text-sm leading-relaxed text-purple-100">
                  Our mission is to build the most reliable and easy-to-use token discovery platform on Solana. We're
                  constantly improving our technology to stay ahead of market changes and help our users succeed.
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                  <div className="bg-gradient-to-r from-purple-500/10 to-purple-600/10 p-4 rounded-lg border border-purple-300/20">
                    <h4 className="text-purple-200 font-orbitron font-semibold mb-2 flex items-center gap-2">
                      <HeartIcon className="h-4 w-4 text-purple-300" /> Core Values
                    </h4>
                    <ul className="list-disc pl-6 space-y-1">
                      <li className="font-orbitron text-sm leading-relaxed text-purple-100">Innovation</li>
                      <li className="font-orbitron text-sm leading-relaxed text-purple-100">Transparency</li>
                      <li className="font-orbitron text-sm leading-relaxed text-purple-100">Security</li>
                      <li className="font-orbitron text-sm leading-relaxed text-purple-100">Community-driven</li>
                    </ul>
                  </div>
                  <div className="bg-gradient-to-r from-purple-500/10 to-purple-600/10 p-4 rounded-lg border border-purple-300/20">
                    <h4 className="text-purple-200 font-orbitron font-semibold mb-2 flex items-center gap-2">
                      <GlobeIcon className="h-4 w-4 text-purple-300" /> Strategic Goals
                    </h4>
                    <ul className="list-disc pl-6 space-y-1">
                      <li className="font-orbitron text-sm leading-relaxed text-purple-100">Market leadership</li>
                      <li className="font-orbitron text-sm leading-relaxed text-purple-100">
                        Technological excellence
                      </li>
                      <li className="font-orbitron text-sm leading-relaxed text-purple-100">User empowerment</li>
                      <li className="font-orbitron text-sm leading-relaxed text-purple-100">Ecosystem growth</li>
                    </ul>
                  </div>
                </div>
              </div>
            </section>

            {/* Technology */}
            <section
              id="technology"
              className="bg-gradient-to-r from-purple-800/30 to-purple-700/30 backdrop-blur-md border border-purple-400/20 rounded-lg p-6 shadow-[0_0_20px_rgba(168,85,247,0.1)]"
            >
              <div className="flex items-center gap-2 mb-4">
                <ZapIcon className="h-6 w-6 text-purple-300" />
                <h2 className="text-2xl font-bold font-orbitron text-purple-200">Technology ⚡</h2>
              </div>
              <div className="space-y-4 text-purple-100">
                <p className="font-orbitron text-sm leading-relaxed">
                  MoonCity AI leverages cutting-edge technologies across multiple domains to deliver superior token
                  sniping capabilities:
                </p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
                  <div className="bg-gradient-to-r from-purple-500/10 to-purple-600/10 p-5 rounded-lg border border-purple-300/20">
                    <div className="flex items-center gap-2 mb-3">
                      <LineChartIcon className="h-5 w-5 text-purple-300" />
                      <h3 className="text-lg font-semibold font-orbitron text-purple-200">
                        Real-time Data Processing 📊
                      </h3>
                    </div>
                    <ul className="list-disc pl-6 space-y-2">
                      <li className="font-orbitron text-sm leading-relaxed">
                        High-throughput data pipelines for processing on-chain transactions and market data with minimal
                        latency
                      </li>
                      <li className="font-orbitron text-sm leading-relaxed">
                        Custom-built Solana RPC nodes for direct blockchain access
                      </li>
                      <li className="font-orbitron text-sm leading-relaxed">
                        Distributed event processing system capable of handling 50,000+ events per second
                      </li>
                    </ul>
                  </div>

                  <div className="bg-gradient-to-r from-purple-500/10 to-purple-600/10 p-5 rounded-lg border border-purple-300/20">
                    <div className="flex items-center gap-2 mb-3">
                      <BrainIcon className="h-5 w-5 text-purple-300" />
                      <h3 className="text-lg font-semibold font-orbitron text-purple-200">
                        Machine Learning Models 🧠
                      </h3>
                    </div>
                    <ul className="list-disc pl-6 space-y-2">
                      <li className="font-orbitron text-sm leading-relaxed">
                        Advanced predictive algorithms that analyze token metrics and market patterns
                      </li>
                      <li className="font-orbitron text-sm leading-relaxed">
                        Neural networks trained on historical token performance data
                      </li>
                      <li className="font-orbitron text-sm leading-relaxed">
                        Sentiment analysis of social media and community channels
                      </li>
                    </ul>
                  </div>

                  <div className="bg-gradient-to-r from-purple-500/10 to-purple-600/10 p-5 rounded-lg border border-purple-300/20">
                    <div className="flex items-center gap-2 mb-3">
                      <UsersIcon className="h-5 w-5 text-purple-300" />
                      <h3 className="text-lg font-semibold font-orbitron text-purple-200">Autonomous Agents 🤖</h3>
                    </div>
                    <ul className="list-disc pl-6 space-y-2">
                      <li className="font-orbitron text-sm leading-relaxed">
                        Self-optimizing trading agents that execute strategies based on user parameters
                      </li>
                      <li className="font-orbitron text-sm leading-relaxed">
                        Multi-strategy execution with dynamic allocation
                      </li>
                      <li className="font-orbitron text-sm leading-relaxed">
                        Reinforcement learning for continuous improvement
                      </li>
                    </ul>
                  </div>

                  <div className="bg-gradient-to-r from-purple-500/10 to-purple-600/10 p-5 rounded-lg border border-purple-300/20">
                    <div className="flex items-center gap-2 mb-3">
                      <ShieldIcon className="h-5 w-5 text-purple-300" />
                      <h3 className="text-lg font-semibold font-orbitron text-purple-200">
                        Security Infrastructure 🔒
                      </h3>
                    </div>
                    <ul className="list-disc pl-6 space-y-2">
                      <li className="font-orbitron text-sm leading-relaxed">
                        Multi-layered security architecture with hardware security modules
                      </li>
                      <li className="font-orbitron text-sm leading-relaxed">
                        Encrypted communication channels and secure key management
                      </li>
                      <li className="font-orbitron text-sm leading-relaxed">
                        Regular security audits and penetration testing
                      </li>
                    </ul>
                  </div>
                </div>

                <div className="mt-6 bg-purple-550/10 border border-purple-350/20 rounded-lg p-4">
                  <h4 className="text-purple-200 font-orbitron font-semibold mb-2 flex items-center gap-2">
                    <span className="text-lg">🔬</span> Research & Development Focus
                  </h4>
                  <p className="font-orbitron text-sm leading-relaxed">
                    Our dedicated R&D team continuously explores emerging technologies and methodologies to enhance our
                    platform's capabilities:
                  </p>
                  <ul className="list-disc pl-6 space-y-2 mt-2">
                    <li className="font-orbitron text-sm leading-relaxed">
                      Advanced pattern recognition for early trend identification
                    </li>
                    <li className="font-orbitron text-sm leading-relaxed">
                      Cross-chain analytics for comprehensive market insights
                    </li>
                    <li className="font-orbitron text-sm leading-relaxed">
                      Quantum-resistant cryptographic methods for future-proof security
                    </li>
                  </ul>
                </div>
              </div>
            </section>

            {/* Architecture - Just showing a preview */}
            <section
              id="architecture"
              className="bg-gradient-to-r from-purple-800/30 to-purple-700/30 backdrop-blur-md border border-purple-400/20 rounded-lg p-6 shadow-[0_0_20px_rgba(168,85,247,0.1)]"
            >
              <div className="flex items-center gap-2 mb-4">
                <LayoutIcon className="h-6 w-6 text-purple-300" />
                <h2 className="text-2xl font-bold font-orbitron text-purple-200">Architecture 🏗️</h2>
              </div>
              <div className="space-y-4 text-purple-100">
                <p className="font-orbitron text-sm leading-relaxed">
                  MoonCity AI's architecture is designed for high performance, scalability, and reliability. Our system
                  consists of several interconnected components working in harmony:
                </p>

                <div className="bg-gradient-to-r from-purple-500/10 to-purple-600/10 p-5 rounded-lg border border-purple-300/20 mt-4">
                  <h3 className="text-lg font-semibold font-orbitron text-purple-200 mb-3">System Components 🧩</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="border border-purple-300/20 rounded-lg p-3">
                      <h4 className="text-purple-300 font-orbitron font-semibold text-sm mb-2">
                        Data Collection Layer
                      </h4>
                      <p className="font-orbitron text-xs leading-relaxed">
                        Distributed network of nodes that monitor blockchain activity, DEX transactions, and social
                        signals
                      </p>
                    </div>
                    <div className="border border-purple-300/20 rounded-lg p-3">
                      <h4 className="text-purple-300 font-orbitron font-semibold text-sm mb-2">Processing Engine</h4>
                      <p className="font-orbitron text-xs leading-relaxed">
                        High-performance computing cluster that analyzes incoming data streams and identifies
                        opportunities
                      </p>
                    </div>
                    <div className="border border-purple-300/20 rounded-lg p-3">
                      <h4 className="text-purple-300 font-orbitron font-semibold text-sm mb-2">Strategy Execution</h4>
                      <p className="font-orbitron text-xs leading-relaxed">
                        Automated trading modules that implement user-defined strategies with millisecond precision
                      </p>
                    </div>
                    <div className="border border-purple-300/20 rounded-lg p-3">
                      <h4 className="text-purple-300 font-orbitron font-semibold text-sm mb-2">User Interface</h4>
                      <p className="font-orbitron text-xs leading-relaxed">
                        Intuitive dashboard for strategy configuration, monitoring, and performance analytics
                      </p>
                    </div>
                  </div>
                </div>

                <div className="flex justify-center mt-6">
                  <div className="bg-gradient-to-r from-purple-500/20 to-purple-600/20 p-4 rounded-lg border border-purple-300/30 max-w-md">
                    <p className="font-orbitron text-sm italic text-center text-purple-200">
                      "Our architecture is designed with a focus on minimal latency, maximum reliability, and seamless
                      scalability to handle the demands of high-frequency trading in the Solana ecosystem."
                    </p>
                  </div>
                </div>

                <p className="font-orbitron text-sm leading-relaxed italic text-purple-200/70 text-center mt-6">
                  [Full architecture details available in the complete whitepaper PDF]
                </p>
              </div>
            </section>

            {/* Roadmap Section */}
            <section
              id="roadmap"
              className="bg-gradient-to-r from-purple-800/30 to-purple-700/30 backdrop-blur-md border border-purple-400/20 rounded-lg p-6 shadow-[0_0_20px_rgba(168,85,247,0.1)]"
            >
              <div className="flex items-center gap-2 mb-4">
                <MapIcon className="h-6 w-6 text-purple-300" />
                <h2 className="text-2xl font-bold font-orbitron text-purple-200">Roadmap 🗺️</h2>
              </div>
              <div className="space-y-6 text-purple-100">
                <p className="font-orbitron text-sm leading-relaxed">
                  Our development roadmap outlines the key milestones and features planned for MoonCity AI:
                </p>

                <div className="relative">
                  {/* Timeline line */}
                  <div className="absolute left-4 top-0 bottom-0 w-0.5 bg-gradient-to-b from-purple-400 to-purple-600"></div>

                  {/* Q2 2023 */}
                  <div className="relative pl-12 pb-8">
                    <div className="absolute left-0 w-8 h-8 rounded-full bg-gradient-to-br from-purple-400 to-purple-600 flex items-center justify-center">
                      <span className="text-white font-bold text-xs">Q1</span>
                    </div>
                    <div className="bg-gradient-to-r from-purple-500/10 to-purple-600/10 p-4 rounded-lg border border-purple-300/20">
                      <h3 className="text-lg font-semibold font-orbitron text-purple-200 mb-2">
                        Q1 2025 - Getting Started ✓ *NOW*
                      </h3>
                      <ul className="list-disc pl-6 space-y-1">
                        <li className="font-orbitron text-sm leading-relaxed">
                          Building our team and technology foundation
                        </li>
                        <li className="font-orbitron text-sm leading-relaxed">Creating the basic platform design</li>
                        <li className="font-orbitron text-sm leading-relaxed">Testing our first AI models</li>
                        <li className="font-orbitron text-sm leading-relaxed">Getting security audits completed</li>
                      </ul>
                    </div>
                  </div>

                  {/* Q3 2023 */}
                  <div className="relative pl-12 pb-8">
                    <div className="absolute left-0 w-8 h-8 rounded-full bg-gradient-to-br from-purple-400 to-purple-600 flex items-center justify-center">
                      <span className="text-white font-bold text-xs">Q2</span>
                    </div>
                    <div className="bg-gradient-to-r from-purple-500/10 to-purple-600/10 p-4 rounded-lg border border-purple-300/20">
                      <h3 className="text-lg font-semibold font-orbitron text-purple-200 mb-2">
                        Q2 2025 - Beta Testing
                      </h3>
                      <ul className="list-disc pl-6 space-y-1">
                        <li className="font-orbitron text-sm leading-relaxed">Launch beta version for early users</li>
                        <li className="font-orbitron text-sm leading-relaxed">
                          Improve AI accuracy based on real data
                        </li>
                        <li className="font-orbitron text-sm leading-relaxed">Add more token analysis features</li>
                        <li className="font-orbitron text-sm leading-relaxed">Build mobile app for iOS and Android</li>
                      </ul>
                    </div>
                  </div>

                  {/* Q4 2023 */}
                  <div className="relative pl-12 pb-8">
                    <div className="absolute left-0 w-8 h-8 rounded-full bg-gradient-to-br from-purple-400 to-purple-600 flex items-center justify-center">
                      <span className="text-white font-bold text-xs">Q3</span>
                    </div>
                    <div className="bg-gradient-to-r from-purple-500/10 to-purple-600/10 p-4 rounded-lg border border-purple-300/20">
                      <h3 className="text-lg font-semibold font-orbitron text-purple-200 mb-2">
                        Q3 2025 - Public Launch
                      </h3>
                      <ul className="list-disc pl-6 space-y-1">
                        <li className="font-orbitron text-sm leading-relaxed">Open platform to all users</li>
                        <li className="font-orbitron text-sm leading-relaxed">Launch MOON token and rewards program</li>
                        <li className="font-orbitron text-sm leading-relaxed">Add advanced trading features</li>
                        <li className="font-orbitron text-sm leading-relaxed">Partner with major crypto exchanges</li>
                      </ul>
                    </div>
                  </div>

                  {/* Q1 2024 */}
                  <div className="relative pl-12 pb-8">
                    <div className="absolute left-0 w-8 h-8 rounded-full bg-gradient-to-br from-purple-400 to-purple-600 flex items-center justify-center">
                      <span className="text-white font-bold text-xs">Q4</span>
                    </div>
                    <div className="bg-gradient-to-r from-purple-500/10 to-purple-600/10 p-4 rounded-lg border border-purple-300/20">
                      <h3 className="text-lg font-semibold font-orbitron text-purple-200 mb-2">
                        Q4 2025 - Growth & Expansion 🚀
                      </h3>
                      <ul className="list-disc pl-6 space-y-1">
                        <li className="font-orbitron text-sm leading-relaxed">Add support for more blockchains</li>
                        <li className="font-orbitron text-sm leading-relaxed">
                          Launch educational content and tutorials
                        </li>
                        <li className="font-orbitron text-sm leading-relaxed">
                          Build community features and social trading
                        </li>
                        <li className="font-orbitron text-sm leading-relaxed">
                          Introduce premium features for power users
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>

                <div className="mt-6 bg-purple-550/10 border border-purple-350/20 rounded-lg p-4">
                  <h4 className="text-purple-200 font-orbitron font-semibold mb-2 flex items-center gap-2">
                    <span className="text-lg">🔮</span> Future Vision (2027+)
                  </h4>
                  <ul className="list-disc pl-6 space-y-2">
                    <li className="font-orbitron text-sm leading-relaxed">
                      Multi-chain support for comprehensive market coverage
                    </li>
                    <li className="font-orbitron text-sm leading-relaxed">
                      Advanced AI-driven market prediction models
                    </li>
                    <li className="font-orbitron text-sm leading-relaxed">Institutional-grade tools and services</li>
                    <li className="font-orbitron text-sm leading-relaxed">Decentralized governance implementation</li>
                  </ul>
                </div>
              </div>
            </section>
          </div>
        </div>
      </div>

      {/* Footer */}
      <Footer />
    </div>
  )
}
