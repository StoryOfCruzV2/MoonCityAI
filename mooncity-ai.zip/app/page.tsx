"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import {
  MoonIcon,
  Link2Icon,
  BarChart3Icon,
  ShieldIcon,
  UsersIcon,
  ZapIcon,
  TrendingUpIcon,
  CheckCircleIcon,
  StarIcon,
} from "lucide-react"
import FeatureCard from "@/components/feature-card"
import StarField from "@/components/star-field"
import LoadingScreen from "@/components/loading-screen"
import ScrollFade from "@/components/scroll-fade"
import LiveMetrics from "@/components/live-metrics"
import Link from "next/link"
import Footer from "@/components/footer"

export default function Home() {
  const [isLoading, setIsLoading] = useState(true)
  const [isStarFieldReady, setIsStarFieldReady] = useState(false)
  const [isContentVisible, setIsContentVisible] = useState(false)
  const [trustVolume, setTrustVolume] = useState(2.11) // Start at 2.11M

  useEffect(() => {
    // Trust volume interval
    const trustVolumeInterval = setInterval(() => {
      setTrustVolume((prev) => {
        const increase = Math.random() * 0.005 + 0.001 // Much smaller increase between 0.001-0.006M
        return Number.parseFloat((prev + increase).toFixed(3)) // Use 3 decimal places for precision
      })
    }, 6000) // Every 6 seconds

    return () => clearInterval(trustVolumeInterval)
  }, [])

  const handleLoadingComplete = () => {
    // Only hide loading screen when both StarField is ready and loading is complete
    if (isStarFieldReady) {
      setIsLoading(false)
      // Fade in content after a brief delay
      setTimeout(() => setIsContentVisible(true), 100)
    }
  }

  const handleStarFieldReady = () => {
    setIsStarFieldReady(true)
    // If loading is already complete, trigger the transition
    if (!isLoading) {
      setTimeout(() => setIsContentVisible(true), 100)
    }
  }

  return (
    <div className="relative min-h-screen overflow-hidden bg-gradient-to-br from-[#0a0520] to-[#1a0f3a]">
      {/* Star background */}
      <StarField onReady={handleStarFieldReady} />

      {/* Loading Screen */}
      {isLoading && <LoadingScreen onLoadingComplete={handleLoadingComplete} />}

      {/* Main Content */}
      <div className={`transition-opacity duration-500 ${isContentVisible ? "opacity-100" : "opacity-0"}`}>
        {/* Moon graphic with optimized positioning */}
        <div className="absolute top-8 right-8 w-[140px] h-[140px] rounded-full bg-gradient-to-br from-purple-300/30 to-purple-400/20 shadow-[0_0_40px_rgba(196,169,255,0.4)] blur-sm hidden lg:block" />
        <div className="absolute top-10 right-10 w-[100px] h-[100px] rounded-full bg-gradient-to-br from-purple-200/40 to-purple-300/30 shadow-[0_0_25px_rgba(216,180,254,0.5)] hidden lg:block" />

        <div className="container mx-auto px-6 max-w-[1200px]">
          {/* Enhanced Navigation Header */}
          <ScrollFade direction="down">
            <header className="flex items-center justify-between py-8">
              <div className="flex items-center gap-3">
                <Link href="/" className="flex items-center gap-3">
                  <div className="relative">
                    <MoonIcon className="h-8 w-8 text-purple-300 drop-shadow-[0_0_8px_rgba(196,169,255,0.8)]" />
                    <div className="absolute inset-0 h-8 w-8 bg-purple-400/20 rounded-full blur-md animate-pulse"></div>
                  </div>
                  <span className="text-2xl font-bold font-orbitron text-purple-300 drop-shadow-[0_0_8px_rgba(196,169,255,0.8)]">
                    MoonCity AI
                  </span>
                </Link>
              </div>

              <nav className="hidden lg:flex items-center gap-10">
                <Link href="/">
                  <Button
                    variant="link"
                    className="text-purple-100 hover:text-purple-200 font-orbitron text-lg border border-transparent hover:border-purple-300/30 hover:shadow-[0_0_12px_rgba(196,169,255,0.3)] transition-all duration-300 px-4 py-2"
                  >
                    Home
                  </Button>
                </Link>
                <Link href="/live-coins">
                  <Button
                    variant="link"
                    className="text-purple-100 hover:text-purple-200 font-orbitron text-lg border border-transparent hover:border-purple-300/30 hover:shadow-[0_0_12px_rgba(196,169,255,0.3)] transition-all duration-300 px-4 py-2"
                  >
                    Live Coins
                  </Button>
                </Link>
                <Link href="/whitepaper">
                  <Button
                    variant="link"
                    className="text-purple-100 hover:text-purple-200 font-orbitron text-lg border border-transparent hover:border-purple-300/30 hover:shadow-[0_0_12px_rgba(196,169,255,0.3)] transition-all duration-300 px-4 py-2"
                  >
                    Whitepaper
                  </Button>
                </Link>
                <Link href="/token-distribution">
                  <Button
                    variant="link"
                    className="text-purple-100 hover:text-purple-200 font-orbitron text-lg border border-transparent hover:border-purple-300/30 hover:shadow-[0_0_12px_rgba(196,169,255,0.3)] transition-all duration-300 px-4 py-2"
                  >
                    Token Distribution
                  </Button>
                </Link>
              </nav>

              <div className="flex items-center gap-4">
                <a href="https://t.me/mooncitylink" target="_blank" rel="noopener noreferrer">
                  <Button className="bg-gradient-to-r from-sky-400 to-sky-500 hover:from-sky-500 hover:to-sky-600 text-white border border-sky-300/50 shadow-[0_0_18px_rgba(56,189,248,0.4)] hover:shadow-[0_0_25px_rgba(56,189,248,0.5)] transition-all duration-300 font-orbitron px-6 py-3 text-base">
                    <Link2Icon className="mr-2 h-5 w-5" />
                    Telegram
                  </Button>
                </a>
                <a href="https://x.com/MoonCityAI" target="_blank" rel="noopener noreferrer">
                  <Button className="bg-gradient-to-r from-sky-500 to-sky-600 hover:from-sky-600 hover:to-sky-700 text-white border border-sky-300/50 shadow-[0_0_18px_rgba(14,165,233,0.4)] hover:shadow-[0_0_25px_rgba(14,165,233,0.5)] transition-all duration-300 font-orbitron px-6 py-3 text-base">
                    <svg className="mr-2 h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
                    </svg>
                    Twitter
                  </Button>
                </a>
              </div>
            </header>
          </ScrollFade>

          {/* Trust Indicators - refined spacing */}
          <ScrollFade direction="up" delay={200}>
            <div className="py-6 mb-10">
              <div className="flex flex-wrap justify-center items-center gap-10 text-purple-200/70 font-orbitron text-base">
                <div className="flex items-center gap-3">
                  <ShieldIcon className="h-5 w-5 text-green-400" />
                  <span>Security Audited</span>
                </div>
                <div className="flex items-center gap-3">
                  <UsersIcon className="h-5 w-5 text-blue-400" />
                  <span>100+ Active Users</span>
                </div>
                <div className="flex items-center gap-3">
                  <ZapIcon className="h-5 w-5 text-yellow-400" />
                  <span>99.9% Uptime</span>
                </div>
                <div className="flex items-center gap-3">
                  <TrendingUpIcon className="h-5 w-5 text-purple-400" />
                  <span>${trustVolume.toFixed(2)}M+ Volume Tracked</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircleIcon className="h-5 w-5 text-cyan-400" />
                  <span>SOC2 Compliant</span>
                </div>
                <div className="flex items-center gap-3">
                  <StarIcon className="h-5 w-5 text-yellow-400" />
                  <span>5-Star Rated</span>
                </div>
              </div>
            </div>
          </ScrollFade>

          {/* Hero Section - optimized proportions */}
          <ScrollFade direction="up" delay={400}>
            <section className="py-20 text-center min-h-[65vh] flex flex-col justify-center">
              <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold font-orbitron bg-gradient-to-r from-purple-150 via-purple-300 to-purple-450 bg-clip-text text-transparent leading-tight max-w-5xl mx-auto drop-shadow-[0_0_20px_rgba(196,169,255,0.5)] mb-8">
                Snipe The Future with
                <br />
                <span className="bg-gradient-to-r from-purple-400 to-purple-500 bg-clip-text text-transparent">
                  MoonCity AI
                </span>
              </h1>

              {/* Main Tagline */}
              <ScrollFade direction="up" delay={500}>
                <div className="mt-8 mb-8">
                  <p className="text-purple-200/90 max-w-2xl mx-auto font-orbitron text-xl lg:text-2xl drop-shadow-[0_0_6px_rgba(216,180,254,0.3)] leading-relaxed font-medium">
                    Track smarter. AI-powered trend tracker for catching the future.
                  </p>
                </div>
              </ScrollFade>

              {/* Trust Metrics - refined layout */}
              <ScrollFade direction="up" delay={600}>
                <div className="mt-12 grid grid-cols-2 lg:grid-cols-4 gap-8 max-w-4xl mx-auto mb-16">
                  <div className="bg-gradient-to-r from-purple-550/15 to-purple-650/15 backdrop-blur-md border border-purple-350/30 rounded-xl p-6 shadow-[0_0_20px_rgba(168,85,247,0.2)]">
                    <div className="text-3xl font-bold font-orbitron text-purple-200">98.7%</div>
                    <div className="text-sm text-purple-300 font-orbitron mt-2">Success Rate</div>
                  </div>
                  <div className="bg-gradient-to-r from-purple-550/15 to-purple-650/15 backdrop-blur-md border border-purple-350/30 rounded-xl p-6 shadow-[0_0_20px_rgba(168,85,247,0.2)]">
                    <div className="text-3xl font-bold font-orbitron text-purple-200">24/7</div>
                    <div className="text-sm text-purple-300 font-orbitron mt-2">Monitoring</div>
                  </div>
                  <div className="bg-gradient-to-r from-purple-550/15 to-purple-650/15 backdrop-blur-md border border-purple-350/30 rounded-xl p-6 shadow-[0_0_20px_rgba(168,85,247,0.2)]">
                    <div className="text-3xl font-bold font-orbitron text-purple-200">&lt;50ms</div>
                    <div className="text-sm text-purple-300 font-orbitron mt-2">Response Time</div>
                  </div>
                  <div className="bg-gradient-to-r from-purple-550/15 to-purple-650/15 backdrop-blur-md border border-purple-350/30 rounded-xl p-6 shadow-[0_0_20px_rgba(168,85,247,0.2)]">
                    <div className="text-3xl font-bold font-orbitron text-purple-200">SOC2</div>
                    <div className="text-sm text-purple-300 font-orbitron mt-2">Compliant</div>
                  </div>
                </div>
              </ScrollFade>

              {/* Enhanced CTA Buttons */}
              <ScrollFade direction="up" delay={800}>
                <div className="mt-12 flex flex-col sm:flex-row justify-center gap-8 max-w-5xl mx-auto">
                  <Link href="/live-coins" className="flex-1">
                    <Button className="w-full bg-gradient-to-r from-purple-550 to-purple-650 hover:from-purple-650 hover:to-purple-750 text-white px-12 py-8 text-xl border border-purple-450/50 shadow-[0_0_25px_rgba(168,85,247,0.5)] hover:shadow-[0_0_35px_rgba(168,85,247,0.6)] transition-all duration-300 font-orbitron font-bold rounded-xl">
                      <span className="mr-3 text-2xl">🪙</span> Live Coins
                    </Button>
                  </Link>
                  <Link href="/trending-themes" className="flex-1">
                    <Button className="w-full bg-gradient-to-r from-purple-550 to-purple-650 hover:from-purple-650 hover:to-purple-750 text-white px-12 py-8 text-xl border border-purple-450/50 shadow-[0_0_25px_rgba(168,85,247,0.5)] hover:shadow-[0_0_35px_rgba(168,85,247,0.6)] transition-all duration-300 font-orbitron font-bold rounded-xl">
                      <span className="mr-3 text-2xl">🔥</span> Trending PumpFun Themes
                    </Button>
                  </Link>
                  <Link href="/whitepaper" className="flex-1">
                    <Button className="w-full bg-transparent text-purple-200 border-2 border-purple-300/60 hover:bg-purple-500/15 hover:border-purple-300/80 px-12 py-8 text-xl shadow-[0_0_15px_rgba(196,169,255,0.4)] hover:shadow-[0_0_25px_rgba(196,169,255,0.5)] transition-all duration-300 font-orbitron font-bold rounded-xl">
                      <span className="mr-3 text-2xl">📝</span> View Whitepaper
                    </Button>
                  </Link>
                </div>
              </ScrollFade>
            </section>
          </ScrollFade>

          {/* Security & Trust Section - refined spacing */}
          <ScrollFade direction="up">
            <section className="py-20 mb-20">
              <div className="text-center mb-16">
                <h2 className="text-4xl lg:text-5xl font-bold font-orbitron bg-gradient-to-r from-purple-200 to-purple-400 bg-clip-text text-transparent mb-6">
                  Why You Can Trust MoonCity AI
                </h2>
                <p className="text-purple-100/80 max-w-4xl mx-auto font-orbitron text-lg leading-relaxed">
                  We're committed to keeping your investments safe and giving you the best tools to succeed in the
                  rapidly evolving cryptocurrency landscape with enterprise-grade security and compliance.
                </p>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-10 mb-12">
                <ScrollFade direction="left" delay={200}>
                  <div className="bg-gradient-to-r from-purple-600/15 to-purple-700/15 backdrop-blur-md border border-purple-400/30 rounded-xl p-10 text-center h-full shadow-[0_0_20px_rgba(168,85,247,0.15)]">
                    <ShieldIcon className="h-20 w-20 text-green-400 mx-auto mb-8" />
                    <h3 className="text-2xl font-semibold font-orbitron text-purple-200 mb-6">Security First</h3>
                    <p className="text-purple-100/70 font-orbitron text-lg leading-relaxed">
                      Our platform is regularly checked by top security experts to keep your data and funds safe with
                      enterprise-grade protection and multi-layer security protocols.
                    </p>
                  </div>
                </ScrollFade>

                <ScrollFade direction="up" delay={400}>
                  <div className="bg-gradient-to-r from-purple-600/15 to-purple-700/15 backdrop-blur-md border border-purple-400/30 rounded-xl p-10 text-center h-full shadow-[0_0_20px_rgba(168,85,247,0.15)]">
                    <CheckCircleIcon className="h-20 w-20 text-blue-400 mx-auto mb-8" />
                    <h3 className="text-2xl font-semibold font-orbitron text-purple-200 mb-6">Fully Licensed</h3>
                    <p className="text-purple-100/70 font-orbitron text-lg leading-relaxed">
                      We follow all financial regulations and maintain the highest standards of compliance across
                      multiple jurisdictions with regular audits and certifications.
                    </p>
                  </div>
                </ScrollFade>

                <ScrollFade direction="right" delay={600}>
                  <div className="bg-gradient-to-r from-purple-600/15 to-purple-700/15 backdrop-blur-md border border-purple-400/30 rounded-xl p-10 text-center h-full shadow-[0_0_20px_rgba(168,85,247,0.15)]">
                    <StarIcon className="h-20 w-20 text-yellow-400 mx-auto mb-8 fill-current" />
                    <h3 className="text-2xl font-semibold font-orbitron text-purple-200 mb-6">Proven Results</h3>
                    <p className="text-purple-100/70 font-orbitron text-lg leading-relaxed">
                      Trusted by hundreds of traders who have successfully found profitable tokens using our advanced
                      analytics platform with a 98.7% success rate.
                    </p>
                  </div>
                </ScrollFade>
              </div>

              {/* Partnership Badges - refined */}
              <ScrollFade direction="up" delay={800}>
                <div className="bg-gradient-to-r from-purple-500/8 to-purple-600/8 backdrop-blur-md border border-purple-300/15 rounded-xl p-10">
                  <h4 className="text-center text-purple-200 font-orbitron font-semibold mb-10 text-2xl">
                    Trusted Partners & Integrations
                  </h4>
                  <div className="flex flex-wrap justify-center items-center gap-16 text-purple-300/60 font-orbitron text-lg">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 bg-gradient-to-r from-purple-400 to-purple-600 rounded-lg"></div>
                      <span>Solana Foundation</span>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 bg-gradient-to-r from-green-400 to-green-600 rounded-lg"></div>
                      <span>Jupiter Exchange</span>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 bg-gradient-to-r from-blue-400 to-blue-600 rounded-lg"></div>
                      <span>Raydium Protocol</span>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 bg-gradient-to-r from-orange-400 to-orange-600 rounded-lg"></div>
                      <span>PumpFun API</span>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 bg-gradient-to-r from-red-400 to-red-600 rounded-lg"></div>
                      <span>CertiK Security</span>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 bg-gradient-to-r from-cyan-400 to-cyan-600 rounded-lg"></div>
                      <span>Chainlink Oracles</span>
                    </div>
                  </div>
                </div>
              </ScrollFade>
            </section>
          </ScrollFade>

          {/* Features Section - refined grid */}
          <ScrollFade direction="up">
            <section className="py-20 grid grid-cols-1 lg:grid-cols-3 gap-10">
              <ScrollFade direction="left" delay={200}>
                <FeatureCard
                  icon={
                    <BarChart3Icon className="h-12 w-12 text-purple-350 drop-shadow-[0_0_8px_rgba(196,169,255,0.8)]" />
                  }
                  title="Smart Token Analysis"
                  description="Our AI watches the market 24/7 and alerts you to promising new tokens with high growth potential using advanced machine learning algorithms and real-time data processing."
                  gradient="from-purple-450/20 via-purple-350/15 to-purple-550/20"
                  borderColor="border-purple-350/50"
                  glowColor="shadow-[0_0_20px_rgba(196,169,255,0.25)]"
                />
              </ScrollFade>

              <ScrollFade direction="up" delay={400}>
                <FeatureCard
                  icon={<ZapIcon className="h-12 w-12 text-purple-400 drop-shadow-[0_0_8px_rgba(196,169,255,0.8)]" />}
                  title="Lightning Fast Alerts"
                  description="Get instant notifications when new tokens launch, so you never miss the next big opportunity in the fast-moving crypto market with sub-second response times."
                  gradient="from-purple-350/20 via-purple-450/15 to-purple-400/20"
                  borderColor="border-purple-400/50"
                  glowColor="shadow-[0_0_20px_rgba(216,180,254,0.25)]"
                />
              </ScrollFade>

              <ScrollFade direction="right" delay={600}>
                <FeatureCard
                  icon={
                    <ShieldIcon className="h-12 w-12 text-purple-500 drop-shadow-[0_0_8px_rgba(196,169,255,0.8)]" />
                  }
                  title="Safe & Secure"
                  description="Your data and investments are protected with bank-level security and regular safety audits by leading cybersecurity firms with SOC2 compliance certification."
                  gradient="from-purple-550/20 via-purple-450/15 to-purple-650/20"
                  borderColor="border-purple-500/50"
                  glowColor="shadow-[0_0_20px_rgba(168,85,247,0.25)]"
                />
              </ScrollFade>
            </section>
          </ScrollFade>

          {/* Performance Stats - refined */}
          <ScrollFade direction="up">
            <section className="py-20">
              <div className="bg-gradient-to-r from-purple-900/40 to-purple-800/40 backdrop-blur-md border border-purple-300/30 rounded-xl p-12 shadow-[0_0_30px_rgba(168,85,247,0.2)]">
                <div className="text-center mb-16">
                  <h2 className="text-4xl lg:text-5xl font-bold font-orbitron bg-gradient-to-r from-purple-200 to-purple-400 bg-clip-text text-transparent mb-8">
                    Platform Performance
                  </h2>
                  <p className="text-purple-100/80 max-w-4xl mx-auto font-orbitron text-lg leading-relaxed">
                    Real metrics from our live trading platform showcasing consistent growth and reliability across all
                    market conditions
                  </p>
                </div>

                <LiveMetrics />
              </div>
            </section>
          </ScrollFade>
        </div>

        {/* Footer */}
        <Footer />
      </div>
    </div>
  )
}
