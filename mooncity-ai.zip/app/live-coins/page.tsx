import LiveLaunches from "@/components/live-launches"
import { Button } from "@/components/ui/button"
import { MoonIcon, Link2Icon } from "lucide-react"
import StarField from "@/components/star-field"
import Link from "next/link"
import Footer from "@/components/footer"

export default function LiveCoinsPage() {
  return (
    <div className="relative min-h-screen overflow-hidden bg-gradient-to-br from-[#0a0520] to-[#1a0f3a]">
      {/* Star background */}
      <StarField />

      {/* Moon graphic with subtle glow */}
      <div className="absolute top-8 right-8 w-[150px] h-[150px] rounded-full bg-gradient-to-br from-purple-300/30 to-purple-400/20 shadow-[0_0_40px_rgba(196,169,255,0.4)] blur-sm hidden md:block" />
      <div className="absolute top-10 right-10 w-[110px] h-[110px] rounded-full bg-gradient-to-br from-purple-200/40 to-purple-300/30 shadow-[0_0_25px_rgba(216,180,254,0.5)] hidden md:block" />

      <div className="container mx-auto px-4">
        {/* Navigation with subtle effects */}
        <header className="flex items-center justify-between py-6">
          <div className="flex items-center gap-2">
            <Link href="/" className="flex items-center gap-2">
              <MoonIcon className="h-6 w-6 text-purple-300 drop-shadow-[0_0_5px_rgba(196,169,255,0.6)]" />
              <span className="text-xl font-bold font-orbitron text-purple-300 drop-shadow-[0_0_5px_rgba(196,169,255,0.6)]">
                MoonCity AI
              </span>
            </Link>
          </div>

          <nav className="hidden md:flex items-center gap-6">
            <Link href="/">
              <Button
                variant="link"
                className="text-purple-100 hover:text-purple-200 font-orbitron border border-transparent hover:border-purple-300/30 hover:shadow-[0_0_10px_rgba(196,169,255,0.2)] transition-all duration-300"
              >
                Home
              </Button>
            </Link>
            <Link href="/live-coins">
              <Button
                variant="link"
                className="text-purple-100 hover:text-purple-200 font-orbitron border border-transparent hover:border-purple-300/30 hover:shadow-[0_0_10px_rgba(196,169,255,0.2)] transition-all duration-300"
              >
                Live Coins
              </Button>
            </Link>
            <Link href="/whitepaper">
              <Button
                variant="link"
                className="text-purple-100 hover:text-purple-200 font-orbitron border border-transparent hover:border-purple-300/30 hover:shadow-[0_0_10px_rgba(196,169,255,0.2)] transition-all duration-300"
              >
                Whitepaper
              </Button>
            </Link>
            <Link href="/token-distribution">
              <Button
                variant="link"
                className="text-purple-100 hover:text-purple-200 font-orbitron border border-transparent hover:border-purple-300/30 hover:shadow-[0_0_10px_rgba(196,169,255,0.2)] transition-all duration-300"
              >
                Token Distribution
              </Button>
            </Link>
          </nav>

          <div className="flex items-center gap-2">
            <a href="https://t.me/mooncitylink" target="_blank" rel="noopener noreferrer">
              <Button className="bg-gradient-to-r from-sky-400 to-sky-500 hover:from-sky-500 hover:to-sky-600 text-white border border-sky-300/50 shadow-[0_0_15px_rgba(56,189,248,0.3)] hover:shadow-[0_0_20px_rgba(56,189,248,0.4)] transition-all duration-300 font-orbitron">
                <Link2Icon className="mr-2 h-4 w-4" />
                Telegram
              </Button>
            </a>
            <a href="https://x.com/MoonCityAI" target="_blank" rel="noopener noreferrer">
              <Button className="bg-gradient-to-r from-sky-500 to-sky-600 hover:from-sky-600 hover:to-sky-700 text-white border border-sky-300/50 shadow-[0_0_15px_rgba(14,165,233,0.3)] hover:shadow-[0_0_20px_rgba(14,165,233,0.4)] transition-all duration-300 font-orbitron">
                <svg className="mr-2 h-4 w-4" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
                </svg>
                Twitter
              </Button>
            </a>
          </div>
        </header>

        {/* Page Title */}
        <div className="py-12 text-center">
          <h1 className="text-4xl md:text-5xl font-bold font-orbitron bg-gradient-to-r from-purple-200 via-purple-300 to-purple-400 bg-clip-text text-transparent leading-tight max-w-4xl mx-auto drop-shadow-[0_0_15px_rgba(196,169,255,0.4)]">
            <span className="mr-2">🪙</span> Live Coins
          </h1>
          <p className="mt-4 text-purple-100 max-w-2xl mx-auto font-orbitron text-lg drop-shadow-[0_0_5px_rgba(216,180,254,0.3)]">
            Real-time tracking of the latest token launches from PumpFun
          </p>
        </div>
      </div>

      {/* Live Launches Section */}
      <LiveLaunches />

      {/* Footer */}
      <Footer />
    </div>
  )
}
