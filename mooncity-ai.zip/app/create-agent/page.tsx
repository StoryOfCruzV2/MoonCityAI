import { Button } from "@/components/ui/button"
import { MoonIcon, Link2Icon, BotIcon, SettingsIcon, CodeIcon } from "lucide-react"
import StarField from "@/components/star-field"
import Link from "next/link"

export default function CreateAgentPage() {
  return (
    <div className="relative min-h-screen overflow-hidden bg-gradient-to-br from-[#0a0520] to-[#1a0f3a]">
      {/* Star background */}
      <StarField />

      {/* Moon graphic with subtle glow */}
      <div className="absolute top-8 right-8 w-[150px] h-[150px] rounded-full bg-gradient-to-br from-purple-300/30 to-purple-400/20 shadow-[0_0_40px_rgba(196,169,255,0.4)] blur-sm hidden md:block" />
      <div className="absolute top-10 right-10 w-[110px] h-[110px] rounded-full bg-gradient-to-br from-purple-200/40 to-purple-300/30 shadow-[0_0_25px_rgba(216,180,254,0.5)] hidden md:block" />

      <div className="container mx-auto px-4">
        {/* Navigation with subtle effects */}
        <header className="flex items-center justify-between py-6">
          <div className="flex items-center gap-2">
            <Link href="/" className="flex items-center gap-2">
              <MoonIcon className="h-6 w-6 text-purple-300 drop-shadow-[0_0_5px_rgba(196,169,255,0.6)]" />
              <span className="text-xl font-bold font-orbitron text-purple-300 drop-shadow-[0_0_5px_rgba(196,169,255,0.6)]">
                MoonCity AI
              </span>
            </Link>
          </div>

          <nav className="hidden md:flex items-center gap-6">
            <Link href="/">
              <Button
                variant="link"
                className="text-purple-100 hover:text-purple-200 font-orbitron border border-transparent hover:border-purple-300/30 hover:shadow-[0_0_10px_rgba(196,169,255,0.2)] transition-all duration-300"
              >
                Home
              </Button>
            </Link>
            <Link href="/live-coins">
              <Button
                variant="link"
                className="text-purple-100 hover:text-purple-200 font-orbitron border border-transparent hover:border-purple-300/30 hover:shadow-[0_0_10px_rgba(196,169,255,0.2)] transition-all duration-300"
              >
                Live Coins
              </Button>
            </Link>
            <Link href="/whitepaper">
              <Button
                variant="link"
                className="text-purple-100 hover:text-purple-200 font-orbitron border border-transparent hover:border-purple-300/30 hover:shadow-[0_0_10px_rgba(196,169,255,0.2)] transition-all duration-300"
              >
                Whitepaper
              </Button>
            </Link>
            <Link href="/token-distribution">
              <Button
                variant="link"
                className="text-purple-100 hover:text-purple-200 font-orbitron border border-transparent hover:border-purple-300/30 hover:shadow-[0_0_10px_rgba(196,169,255,0.2)] transition-all duration-300"
              >
                Token Distribution
              </Button>
            </Link>
          </nav>

          <div className="flex items-center gap-2">
            <a href="https://t.me/mooncitylink" target="_blank" rel="noopener noreferrer">
              <Button className="bg-gradient-to-r from-sky-400 to-sky-500 hover:from-sky-500 hover:to-sky-600 text-white border border-sky-300/50 shadow-[0_0_15px_rgba(56,189,248,0.3)] hover:shadow-[0_0_20px_rgba(56,189,248,0.4)] transition-all duration-300 font-orbitron">
                <Link2Icon className="mr-2 h-4 w-4" />
                Telegram
              </Button>
            </a>
            <a href="https://x.com/MoonCityAI" target="_blank" rel="noopener noreferrer">
              <Button className="bg-gradient-to-r from-sky-500 to-sky-600 hover:from-sky-600 hover:to-sky-700 text-white border border-sky-300/50 shadow-[0_0_15px_rgba(14,165,233,0.3)] hover:shadow-[0_0_20px_rgba(14,165,233,0.4)] transition-all duration-300 font-orbitron">
                <svg className="mr-2 h-4 w-4" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
                </svg>
                Twitter
              </Button>
            </a>
          </div>
        </header>

        {/* Create Agent Header */}
        <div className="py-12 text-center">
          <h1 className="text-4xl md:text-6xl font-bold font-orbitron bg-gradient-to-r from-purple-200 via-purple-300 to-purple-400 bg-clip-text text-transparent leading-tight max-w-4xl mx-auto drop-shadow-[0_0_15px_rgba(196,169,255,0.4)]">
            Create Your Sniping Agent
          </h1>
          <p className="mt-4 text-purple-100 max-w-2xl mx-auto font-orbitron text-lg drop-shadow-[0_0_5px_rgba(216,180,254,0.3)]">
            Configure your AI-powered trading agent to automate your token sniping strategy
          </p>
        </div>

        {/* Agent Creation Interface */}
        <div className="max-w-4xl mx-auto bg-gradient-to-r from-purple-900/30 to-purple-800/30 backdrop-blur-md border border-purple-300/20 rounded-lg p-8 shadow-[0_0_20px_rgba(168,85,247,0.1)] mb-16">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="md:col-span-1">
              <div className="space-y-6">
                <div className="bg-gradient-to-r from-purple-500/20 to-purple-600/20 backdrop-blur-md border border-purple-300/30 rounded-lg p-4 flex flex-col items-center">
                  <div className="w-16 h-16 bg-gradient-to-br from-purple-400 to-purple-600 rounded-full flex items-center justify-center mb-4">
                    <BotIcon className="h-8 w-8 text-white" />
                  </div>
                  <h3 className="text-lg font-semibold font-orbitron text-purple-200 mb-2">Agent Type</h3>
                  <p className="text-xs text-center text-purple-100/80 font-orbitron">
                    Select your agent's behavior and strategy type
                  </p>
                </div>

                <div className="bg-gradient-to-r from-purple-500/20 to-purple-600/20 backdrop-blur-md border border-purple-300/30 rounded-lg p-4 flex flex-col items-center">
                  <div className="w-16 h-16 bg-gradient-to-br from-purple-400 to-purple-600 rounded-full flex items-center justify-center mb-4">
                    <SettingsIcon className="h-8 w-8 text-white" />
                  </div>
                  <h3 className="text-lg font-semibold font-orbitron text-purple-200 mb-2">Parameters</h3>
                  <p className="text-xs text-center text-purple-100/80 font-orbitron">
                    Configure trading parameters and risk tolerance
                  </p>
                </div>

                <div className="bg-gradient-to-r from-purple-500/20 to-purple-600/20 backdrop-blur-md border border-purple-300/30 rounded-lg p-4 flex flex-col items-center">
                  <div className="w-16 h-16 bg-gradient-to-br from-purple-400 to-purple-600 rounded-full flex items-center justify-center mb-4">
                    <CodeIcon className="h-8 w-8 text-white" />
                  </div>
                  <h3 className="text-lg font-semibold font-orbitron text-purple-200 mb-2">Advanced</h3>
                  <p className="text-xs text-center text-purple-100/80 font-orbitron">
                    Custom logic and advanced configuration options
                  </p>
                </div>
              </div>
            </div>

            <div className="md:col-span-2">
              <div className="bg-gradient-to-r from-purple-500/10 to-purple-600/10 backdrop-blur-md border border-purple-300/20 rounded-lg p-6">
                <h3 className="text-xl font-bold font-orbitron text-purple-200 mb-4">Agent Configuration</h3>

                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-orbitron text-purple-200 mb-1">Agent Name</label>
                    <input
                      type="text"
                      className="w-full bg-purple-900/30 border border-purple-300/30 rounded-md px-3 py-2 text-purple-100 font-orbitron text-sm focus:outline-none focus:ring-2 focus:ring-purple-500/50"
                      placeholder="My Sniping Agent"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-orbitron text-purple-200 mb-1">Strategy Type</label>
                    <select className="w-full bg-purple-900/30 border border-purple-300/30 rounded-md px-3 py-2 text-purple-100 font-orbitron text-sm focus:outline-none focus:ring-2 focus:ring-purple-500/50">
                      <option>New Token Sniper</option>
                      <option>Momentum Trader</option>
                      <option>Volatility Hunter</option>
                      <option>Custom Strategy</option>
                    </select>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-orbitron text-purple-200 mb-1">Max Investment</label>
                      <input
                        type="text"
                        className="w-full bg-purple-900/30 border border-purple-300/30 rounded-md px-3 py-2 text-purple-100 font-orbitron text-sm focus:outline-none focus:ring-2 focus:ring-purple-500/50"
                        placeholder="0.5 SOL"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-orbitron text-purple-200 mb-1">Risk Level</label>
                      <select className="w-full bg-purple-900/30 border border-purple-300/30 rounded-md px-3 py-2 text-purple-100 font-orbitron text-sm focus:outline-none focus:ring-2 focus:ring-purple-500/50">
                        <option>Conservative</option>
                        <option>Moderate</option>
                        <option>Aggressive</option>
                        <option>Custom</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-orbitron text-purple-200 mb-1">Target Tokens</label>
                    <div className="flex gap-2 flex-wrap">
                      <span className="bg-purple-500/20 border border-purple-300/30 rounded-md px-2 py-1 text-xs font-orbitron text-purple-200">
                        DeFi
                      </span>
                      <span className="bg-purple-500/20 border border-purple-300/30 rounded-md px-2 py-1 text-xs font-orbitron text-purple-200">
                        Gaming
                      </span>
                      <span className="bg-purple-500/20 border border-purple-300/30 rounded-md px-2 py-1 text-xs font-orbitron text-purple-200">
                        AI
                      </span>
                      <span className="bg-purple-500/20 border border-purple-300/30 rounded-md px-2 py-1 text-xs font-orbitron text-purple-200">
                        NFT
                      </span>
                      <span className="bg-purple-500/20 border border-purple-300/30 rounded-md px-2 py-1 text-xs font-orbitron text-purple-200">
                        + Add
                      </span>
                    </div>
                  </div>

                  <div className="pt-4">
                    <Button className="w-full bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700 text-white py-3 border border-purple-400/50 shadow-[0_0_20px_rgba(168,85,247,0.4)] hover:shadow-[0_0_25px_rgba(168,85,247,0.5)] transition-all duration-300 font-orbitron font-bold">
                      Create Agent
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
