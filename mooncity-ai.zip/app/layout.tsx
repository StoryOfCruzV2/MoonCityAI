import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import StarField from "@/components/star-field"
import MoonTexture from "@/components/moon-texture"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "MoonCity AI",
  description: "Discover the future of crypto with MoonCity AI",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <StarField />
        <MoonTexture size={180} position={{ top: "40px", right: "40px" }} zIndex={0} />
        {children}
      </body>
    </html>
  )
}
